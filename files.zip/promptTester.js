// ============================================================
//  src/evals/promptTester.js — Automatic Prompt Testing
//  A/B tests prompt variants, measures scores, ranks them
// ============================================================
import { askClaude } from '../agents/claudeAgent.js';
import { askOpenAI } from '../agents/openaiAgent.js';
import { scoreResponse, batchScore } from './scorer.js';
import { saveEval } from '../storage/evalStore.js';
import { log } from '../core/logger.js';
import { runParallel } from '../core/agentRunner.js';
import { v4 as uuid } from 'uuid';

/**
 * Test a set of prompt variants against a fixed set of test cases.
 *
 * @param {object} config
 * @param {Array<{name, template}>} config.variants - Prompt variants to test
 * @param {Array<{input, reference?}>} config.testCases - Inputs + optional ground truth
 * @param {'claude'|'gpt'|'both'} config.model - Which model(s) to test
 * @returns {Promise<PromptTestReport>}
 */
export async function runPromptTest(config) {
  const { variants, testCases, model = 'both', name = 'Unnamed Test' } = config;

  log.eval(`Starting prompt test: "${name}" — ${variants.length} variants × ${testCases.length} cases`);

  const results = [];

  for (const variant of variants) {
    log.eval(`Testing variant: "${variant.name}"`);
    const variantResults = [];

    for (const testCase of testCases) {
      const prompt = variant.template.replace('{{INPUT}}', testCase.input);

      // Run model(s)
      const modelTasks = [];
      if (model === 'claude' || model === 'both') {
        modelTasks.push({ name: 'claude', fn: () => askClaude(prompt) });
      }
      if (model === 'gpt' || model === 'both') {
        modelTasks.push({ name: 'gpt', fn: () => askOpenAI(prompt) });
      }

      const modelResults = await runParallel(modelTasks, { concurrency: 2 });

      for (const mr of modelResults) {
        if (mr.status !== 'fulfilled') continue;
        const responseText = mr.result.text;
        const scored = await scoreResponse(testCase.input, responseText, testCase.reference);

        variantResults.push({
          variantName:   variant.name,
          model:         mr.name,
          input:         testCase.input,
          response:      responseText,
          score:         scored.weightedScore,
          grade:         scored.grade,
          scores:        scored.scores,
          durationMs:    mr.durationMs,
        });
      }
    }

    // Aggregate stats for this variant
    const avgScore = average(variantResults.map(r => r.score));
    results.push({
      variant:       variant.name,
      template:      variant.template,
      avgScore,
      grade:         scoreToGrade(avgScore),
      cases:         variantResults,
      runCount:      variantResults.length,
    });
  }

  // Sort by score
  results.sort((a, b) => b.avgScore - a.avgScore);

  const report = {
    id:         uuid(),
    name,
    timestamp:  new Date().toISOString(),
    winner:     results[0]?.variant,
    results,
    summary:    buildSummary(results),
  };

  await saveEval('prompt_tests', report);
  log.eval(`Prompt test complete. Winner: "${report.winner}" (score: ${results[0]?.avgScore.toFixed(2)})`);

  return report;
}

/**
 * Rapid A/B test: compare exactly 2 prompts on 1 question.
 */
export async function abTest(promptA, promptB, question, model = 'claude') {
  const fn = model === 'claude' ? askClaude : askOpenAI;
  const [resA, resB] = await Promise.all([fn(promptA), fn(promptB)]);
  const [scoreA, scoreB] = await Promise.all([
    scoreResponse(question, resA.text),
    scoreResponse(question, resB.text),
  ]);

  return {
    A: { prompt: promptA.slice(0, 100), response: resA.text, score: scoreA.weightedScore, grade: scoreA.grade },
    B: { prompt: promptB.slice(0, 100), response: resB.text, score: scoreB.weightedScore, grade: scoreB.grade },
    winner: scoreA.weightedScore >= scoreB.weightedScore ? 'A' : 'B',
  };
}

// ─── Helpers ─────────────────────────────────────────────
function average(arr) {
  if (!arr.length) return 0;
  return parseFloat((arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(2));
}

function scoreToGrade(s) {
  if (s >= 9) return 'A+'; if (s >= 8) return 'A';
  if (s >= 7) return 'B';  if (s >= 6) return 'C';
  if (s >= 5) return 'D';  return 'F';
}

function buildSummary(results) {
  return results.map(r => ({
    variant: r.variant,
    avgScore: r.avgScore,
    grade: r.grade,
  }));
}
