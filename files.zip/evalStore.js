// ============================================================
//  src/storage/evalStore.js
// ============================================================
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dir = path.dirname(fileURLToPath(import.meta.url));
const EVALS = path.resolve(__dir, '../../data/evals');

function getFile(category) {
  if (!fs.existsSync(EVALS)) fs.mkdirSync(EVALS, { recursive: true });
  return path.join(EVALS, `${category}.json`);
}

function readFile(file) {
  if (!fs.existsSync(file)) return [];
  try { return JSON.parse(fs.readFileSync(file, 'utf-8')); } catch { return []; }
}

export function saveEval(category, data) {
  const file = getFile(category);
  const arr  = readFile(file);
  arr.unshift(data);
  fs.writeFileSync(file, JSON.stringify(arr.slice(0, 200), null, 2), 'utf-8');
}

export function loadEvals(category, limit = 20) {
  return readFile(getFile(category)).slice(0, limit);
}

export function listEvalCategories() {
  if (!fs.existsSync(EVALS)) return [];
  return fs.readdirSync(EVALS).filter(f => f.endsWith('.json')).map(f => f.replace('.json', ''));
}
