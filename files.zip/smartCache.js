// ============================================================
//  src/rag/smartCache.js — Smart Vector Cache
//
//  Flow:
//    checkCache(query)
//      → HIT  (score >= threshold) → return cached answer instantly
//      → MISS → caller runs AI + web → saveToCache(query, answer)
//
//  Storage:
//    Primary  → ChromaDB (semantic search, survives restarts)
//    Fallback → data/cache.json (when ChromaDB is offline)
//
//  Each cache entry stores:
//    query, answer, source, model, hitCount, avgScore,
//    createdAt, lastHitAt, webSearchUsed, tags
// ============================================================

import fs            from 'fs';
import path          from 'path';
import { fileURLToPath } from 'url';
import { v4 as uuid }   from 'uuid';
import { ChromaClient } from 'chromadb';
import { generateEmbedding } from '../agents/openaiAgent.js';
import { log }       from '../core/logger.js';

// ─── Config ───────────────────────────────────────────────
const HIT_THRESHOLD  = parseFloat(process.env.CACHE_HIT_THRESHOLD  || '0.85'); // cosine sim
const SOFT_THRESHOLD = parseFloat(process.env.CACHE_SOFT_THRESHOLD || '0.72'); // suggest but still re-run
const MAX_CACHE_AGE_DAYS = parseInt(process.env.CACHE_MAX_AGE_DAYS || '30');
const COLLECTION_NAME = 'utracodes_smart_cache';

// ─── File fallback path ────────────────────────────────────
const __dir      = path.dirname(fileURLToPath(import.meta.url));
const CACHE_FILE = path.resolve(__dir, '../../data/cache.json');

// ─── State ────────────────────────────────────────────────
let _client     = null;
let _collection = null;
let _chromaReady = false;

// In-memory index for file-based fallback (query → entry)
let _fileCache  = null;

// ─── Init ─────────────────────────────────────────────────

/**
 * Initialize smart cache. Called once at startup.
 * Tries ChromaDB first, gracefully falls back to file cache.
 */
export async function initSmartCache() {
  // Always init file cache as fallback
  _fileCache = loadFileCache();

  // Try ChromaDB
  try {
    const chromaUrl = process.env.CHROMA_URL || 'http://localhost:8000';
    _client = new ChromaClient({ path: chromaUrl });
    await _client.heartbeat();

    _collection = await _client.getOrCreateCollection({
      name: COLLECTION_NAME,
      metadata: {
        description:  'utracodes smart answer cache',
        hnsw_space:   'cosine',
      },
    });

    _chromaReady = true;
    const count  = await _collection.count();
    log.rag(`Smart cache ready — ChromaDB (${count} entries) + file fallback (${_fileCache.size} entries)`);
  } catch {
    _chromaReady = false;
    log.warn(`Smart cache: ChromaDB offline — using file cache only (${_fileCache.size} entries)`);
  }

  return { chromaReady: _chromaReady, fileEntries: _fileCache.size };
}

// ─── Core: Check Cache ────────────────────────────────────

/**
 * Look up a query in the smart cache.
 *
 * @param {string} query
 * @returns {Promise<CacheCheckResult>}
 *
 * CacheCheckResult:
 *   { hit: true,  entry, score, source: 'chroma'|'file' }  — strong match, skip AI
 *   { hit: false, soft: true,  entry, score }              — partial match, use as context but still call AI
 *   { hit: false, soft: false }                            — no match at all
 */
export async function checkCache(query) {
  const normalizedQuery = normalize(query);

  // ── Try ChromaDB first ─────────────────────────────────
  if (_chromaReady && _collection) {
    try {
      const count = await _collection.count();
      if (count === 0) return { hit: false, soft: false };

      const embedding = await generateEmbedding(normalizedQuery);
      const res = await _collection.query({
        queryEmbeddings: [embedding],
        nResults: Math.min(3, count),  // top 3 candidates
      });

      const hits = (res.ids[0] || []).map((id, i) => ({
        id,
        text:      res.documents[0][i],
        metadata:  res.metadatas[0][i],
        score:     1 - (res.distances?.[0]?.[i] ?? 1),
      })).sort((a, b) => b.score - a.score);

      const best = hits[0];
      if (!best) return { hit: false, soft: false };

      log.debug(`Cache check: best score=${best.score.toFixed(3)} for "${query.slice(0, 50)}"`);

      // ── Strong hit ──────────────────────────────────────
      if (best.score >= HIT_THRESHOLD) {
        // Check cache age
        const entry = parseMeta(best);
        if (isFresh(entry)) {
          await bumpHitCount(best.id, entry);
          log.rag(`✅ Cache HIT  score=${best.score.toFixed(3)}  "${query.slice(0, 60)}"`);
          return { hit: true, entry, score: best.score, source: 'chroma' };
        }
        log.rag(`Cache entry expired, treating as MISS`);
      }

      // ── Soft hit (useful context but not confident enough) ─
      if (best.score >= SOFT_THRESHOLD) {
        const entry = parseMeta(best);
        log.rag(`〜 Cache SOFT score=${best.score.toFixed(3)}  will still call AI but pass as context`);
        return { hit: false, soft: true, entry, score: best.score, source: 'chroma' };
      }

      return { hit: false, soft: false };

    } catch (err) {
      log.warn('Cache ChromaDB lookup failed, trying file cache', err.message);
    }
  }

  // ── Fallback: File cache with keyword similarity ────────
  return checkFileCache(normalizedQuery);
}

// ─── Core: Save to Cache ──────────────────────────────────

/**
 * Save a new answer to the smart cache.
 *
 * @param {string} query
 * @param {object} data
 * @param {string} data.answer         - Best answer text to cache
 * @param {string} data.source         - 'claude' | 'gpt' | 'web' | 'combined'
 * @param {string} data.model          - Model name
 * @param {boolean} data.webSearchUsed - Whether web search was used
 * @param {number} [data.qualityScore] - Score 0–10 if available
 * @param {string[]} [data.tags]       - Optional topic tags
 */
export async function saveToCache(query, data) {
  const id    = `cache_${uuid()}`;
  const entry = {
    id,
    query:         normalize(query),
    originalQuery: query,
    answer:        data.answer,
    source:        data.source || 'unknown',
    model:         data.model  || 'unknown',
    webSearchUsed: data.webSearchUsed || false,
    qualityScore:  data.qualityScore  || null,
    tags:          data.tags || [],
    hitCount:      0,
    createdAt:     new Date().toISOString(),
    lastHitAt:     null,
  };

  // ── Save to ChromaDB ─────────────────────────────────────
  if (_chromaReady && _collection) {
    try {
      const embedding = await generateEmbedding(entry.query);
      const docText   = `Q: ${entry.query}\nA: ${entry.answer.slice(0, 1000)}`;

      await _collection.add({
        ids:        [id],
        embeddings: [embedding],
        documents:  [docText],
        metadatas:  [serializeMeta(entry)],
      });

      log.rag(`💾 Cached to ChromaDB: "${query.slice(0, 60)}" [${entry.source}]`);
    } catch (err) {
      log.warn('Failed to save to ChromaDB cache, saving to file only', err.message);
    }
  }

  // ── Always save to file cache as backup ─────────────────
  _fileCache.set(id, entry);
  saveFileCache(_fileCache);
  if (!_chromaReady) {
    log.rag(`💾 Cached to file: "${query.slice(0, 60)}" [${entry.source}]`);
  }

  return id;
}

// ─── Cache Management ─────────────────────────────────────

/** Get cache stats. */
export async function getCacheStats() {
  const fileCount   = _fileCache?.size || 0;
  let chromaCount   = 0;

  if (_chromaReady && _collection) {
    try { chromaCount = await _collection.count(); } catch {}
  }

  const entries = Array.from(_fileCache?.values() || []);
  const hitTotal = entries.reduce((s, e) => s + (e.hitCount || 0), 0);
  const sources  = groupBy(entries, 'source');

  return {
    chromaReady:  _chromaReady,
    chromaCount,
    fileCount,
    totalHits:    hitTotal,
    hitThreshold: HIT_THRESHOLD,
    softThreshold: SOFT_THRESHOLD,
    maxAgeDays:   MAX_CACHE_AGE_DAYS,
    bySource:     sources,
  };
}

/** Delete a specific cache entry by id. */
export async function deleteCacheEntry(id) {
  _fileCache.delete(id);
  saveFileCache(_fileCache);
  if (_chromaReady && _collection) {
    try { await _collection.delete({ ids: [id] }); } catch {}
  }
}

/** Clear the entire cache. */
export async function clearCache() {
  _fileCache = new Map();
  saveFileCache(_fileCache);
  if (_chromaReady && _collection) {
    try {
      await _client.deleteCollection(COLLECTION_NAME);
      _collection = await _client.createCollection({ name: COLLECTION_NAME });
    } catch (err) {
      log.warn('Failed to clear ChromaDB cache', err.message);
    }
  }
  log.warn('Smart cache cleared');
}

// ─── Internal Helpers ─────────────────────────────────────

function normalize(query) {
  return query.trim().toLowerCase().replace(/\s+/g, ' ');
}

function isFresh(entry) {
  if (!entry.createdAt) return true;
  const ageDays = (Date.now() - new Date(entry.createdAt).getTime()) / 86_400_000;
  return ageDays <= MAX_CACHE_AGE_DAYS;
}

function parseMeta(chromaResult) {
  const m = chromaResult.metadata || {};
  return {
    id:            chromaResult.id,
    query:         m.query         || '',
    originalQuery: m.originalQuery || '',
    answer:        m.answer        || chromaResult.text || '',
    source:        m.source        || 'unknown',
    model:         m.model         || 'unknown',
    webSearchUsed: m.webSearchUsed === 'true' || m.webSearchUsed === true,
    qualityScore:  m.qualityScore  ? parseFloat(m.qualityScore) : null,
    hitCount:      m.hitCount      ? parseInt(m.hitCount)       : 0,
    createdAt:     m.createdAt     || null,
    lastHitAt:     m.lastHitAt     || null,
    tags:          m.tags          ? m.tags.split(',')          : [],
  };
}

// ChromaDB metadata must be flat + string/number/bool only
function serializeMeta(entry) {
  return {
    query:         entry.query,
    originalQuery: entry.originalQuery,
    answer:        entry.answer.slice(0, 2000), // ChromaDB metadata limit
    source:        entry.source,
    model:         entry.model,
    webSearchUsed: String(entry.webSearchUsed),
    qualityScore:  entry.qualityScore !== null ? String(entry.qualityScore) : '',
    hitCount:      String(entry.hitCount),
    createdAt:     entry.createdAt,
    lastHitAt:     entry.lastHitAt || '',
    tags:          entry.tags.join(','),
  };
}

async function bumpHitCount(id, entry) {
  const updated = {
    ...entry,
    hitCount:  (entry.hitCount || 0) + 1,
    lastHitAt: new Date().toISOString(),
  };

  // Update file cache
  _fileCache.set(id, updated);
  saveFileCache(_fileCache);

  // Update ChromaDB metadata
  if (_chromaReady && _collection) {
    try {
      await _collection.update({
        ids:       [id],
        metadatas: [serializeMeta(updated)],
      });
    } catch {}
  }
}

// ─── File cache helpers ───────────────────────────────────

function loadFileCache() {
  if (!fs.existsSync(CACHE_FILE)) return new Map();
  try {
    const raw  = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf-8'));
    const map  = new Map();
    for (const entry of raw) map.set(entry.id, entry);
    return map;
  } catch { return new Map(); }
}

function saveFileCache(map) {
  const dir = path.dirname(CACHE_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(CACHE_FILE, JSON.stringify(Array.from(map.values()), null, 2), 'utf-8');
}

function checkFileCache(normalizedQuery) {
  if (!_fileCache || _fileCache.size === 0) return { hit: false, soft: false };

  // Simple word-overlap similarity for file cache
  const queryWords = new Set(normalizedQuery.split(/\s+/).filter(w => w.length > 3));
  let bestScore  = 0;
  let bestEntry  = null;

  for (const entry of _fileCache.values()) {
    if (!isFresh(entry)) continue;
    const entryWords = new Set((entry.query || '').split(/\s+/).filter(w => w.length > 3));
    const overlap    = [...queryWords].filter(w => entryWords.has(w)).length;
    const score      = queryWords.size ? overlap / Math.max(queryWords.size, entryWords.size) : 0;
    if (score > bestScore) { bestScore = score; bestEntry = entry; }
  }

  // File cache uses slightly lower threshold (keyword match is less precise than vector)
  if (bestScore >= 0.8 && bestEntry) {
    bumpHitCount(bestEntry.id, bestEntry).catch(() => {});
    log.rag(`✅ Cache HIT (file) score=${bestScore.toFixed(2)}  "${normalizedQuery.slice(0, 60)}"`);
    return { hit: true, entry: bestEntry, score: bestScore, source: 'file' };
  }
  if (bestScore >= 0.6 && bestEntry) {
    return { hit: false, soft: true, entry: bestEntry, score: bestScore, source: 'file' };
  }
  return { hit: false, soft: false };
}

function groupBy(arr, key) {
  return arr.reduce((acc, item) => {
    acc[item[key] || 'unknown'] = (acc[item[key] || 'unknown'] || 0) + 1;
    return acc;
  }, {});
}
