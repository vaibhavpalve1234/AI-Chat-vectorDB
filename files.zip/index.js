// ============================================================
//  src/index.js — utracodes-pro CLI
//  Autonomous Multi-Agent AI Evaluation System
// ============================================================
import 'dotenv/config';
import readline from 'readline';
import ora      from 'ora';
import chalk    from 'chalk';

// Core
import { log }           from './core/logger.js';
import { runParallel }   from './core/agentRunner.js';
import {
  printBanner, printHelp, printResponse, printScores,
  printComparison, printSearchResult, printStats,
  printEvalReport, printDatasetReport, printRecent,
} from './core/display.js';

// Agents
import { runComparison }    from './agents/orchestrator.js';
import { researchAgent }    from './agents/searchAgent.js';
import { generateDataset, generateBenchmark } from './agents/datasetAgent.js';

// RAG + Vector + Smart Cache
import { initVectorStore, isReady, getCount, COLLECTIONS } from './rag/vectorStore.js';
import { semanticSearch }   from './rag/vectorStore.js';
import { initSmartCache, getCacheStats, clearCache } from './rag/smartCache.js';

// Storage
import { getHistoryStats, loadHistory } from './storage/historyStore.js';
import { listDatasets }     from './storage/datasetStore.js';
import { listEvalCategories } from './storage/evalStore.js';

// Evals
import { runPromptTest }   from './evals/promptTester.js';
import { analyzeAndImprove } from './evals/selfImprover.js';

// Tools (register them)
import './tools/webSearch.js';
import './tools/codeExecutor.js';

// ─── Env validation ────────────────────────────────────────
function validateEnv() {
  const required = [];
  if (!process.env.ANTHROPIC_API_KEY?.startsWith('sk-')) required.push('ANTHROPIC_API_KEY');
  if (!process.env.OPENAI_API_KEY?.startsWith('sk-'))    required.push('OPENAI_API_KEY');
  if (required.length) {
    console.log(chalk.red('\n❌ Missing or invalid API keys in .env:\n') +
      required.map(k => chalk.yellow(`   • ${k}`)).join('\n') +
      chalk.gray('\n\nCopy .env.example → .env and fill in your keys.\n'));
    process.exit(1);
  }
  if (!process.env.TAVILY_API_KEY) {
    log.warn('TAVILY_API_KEY not set — web search agent disabled');
  }
}

// ─── Main ──────────────────────────────────────────────────
async function main() {
  validateEnv();
  printBanner();

  // Init vector store
  const spinner = ora({ text: 'Connecting to ChromaDB vector store...', color: 'cyan' }).start();
  const vectorReady = await initVectorStore();
  if (vectorReady) {
    const hCount = await getCount(COLLECTIONS.HISTORY);
    spinner.succeed(chalk.cyan(`ChromaDB ready — ${hCount} history vectors`));
  } else {
    spinner.warn(chalk.yellow('ChromaDB offline — file storage only') +
      chalk.gray('\n  Run: pip install chromadb && chroma run --path ./data/chromadb'));
  }

  // Init smart cache
  const cacheSpinner = ora({ text: 'Loading smart answer cache...', color: 'blue' }).start();
  const cacheStatus = await initSmartCache();
  const cacheStats  = await getCacheStats();
  cacheSpinner.succeed(
    chalk.blue(`Smart cache ready — `) +
    chalk.yellow(`${cacheStats.chromaCount || cacheStats.fileCount} entries`) +
    chalk.gray(` | threshold: ${cacheStats.hitThreshold} | max age: ${cacheStats.maxAgeDays}d`)
  );

  // State
  let useWebSearch = false;

  console.log(chalk.gray('\n  Type a question to compare Claude vs ChatGPT, or /help for all commands.\n'));

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

  const prompt = () => rl.question(chalk.bold.white('you › '), async (input) => {
    const trimmed = input.trim();
    if (!trimmed) return prompt();

    // ─── Built-in commands ───────────────────────────────
    if (trimmed === '/exit' || trimmed === '/quit') {
      console.log(chalk.cyan('\nGoodbye! 👋\n'));
      rl.close(); process.exit(0);
    }

    if (trimmed === '/help')   { printHelp();                     return prompt(); }
    if (trimmed === '/stats')  { printStats(getHistoryStats());   return prompt(); }
    if (trimmed === '/recent') { printRecent(loadHistory(5));     return prompt(); }

    if (trimmed === '/web on')  { useWebSearch = true;  console.log(chalk.green('  ✔ Web search enabled')); return prompt(); }
    if (trimmed === '/web off') { useWebSearch = false; console.log(chalk.yellow('  ✔ Web search disabled')); return prompt(); }

    // ─── Cache commands ──────────────────────────────────
    if (trimmed === '/cache') {
      const s = await getCacheStats();
      console.log('\n' + chalk.bold.blue('⚡ Smart Cache Status'));
      console.log(chalk.gray('─'.repeat(50)));
      console.log(`  ${chalk.bold('Backend:')}      ${s.chromaReady ? chalk.green('ChromaDB ✔') : chalk.yellow('File-only ⚠')}`);
      console.log(`  ${chalk.bold('Entries:')}      ${chalk.yellow(s.chromaReady ? s.chromaCount : s.fileCount)}`);
      console.log(`  ${chalk.bold('Total hits:')}   ${chalk.green(s.totalHits)}`);
      console.log(`  ${chalk.bold('Hit threshold:')}${chalk.cyan(` ${s.hitThreshold} cosine similarity`)}`);
      console.log(`  ${chalk.bold('Soft threshold:')}${chalk.cyan(` ${s.softThreshold} (use as hint)`)}`);
      console.log(`  ${chalk.bold('Max age:')}      ${chalk.gray(s.maxAgeDays + ' days')}`);
      if (s.bySource && Object.keys(s.bySource).length) {
        console.log(`  ${chalk.bold('By source:')}    ` + Object.entries(s.bySource).map(([k,v]) => `${k}:${v}`).join(' | '));
      }
      console.log(chalk.gray('\n  /cache clear  — wipe all cache entries'));
      console.log(chalk.gray('  /cache off    — bypass cache for one query: /nocache <q>\n'));
      return prompt();
    }

    if (trimmed === '/cache clear') {
      const sp = ora('Clearing smart cache...').start();
      await clearCache();
      sp.succeed(chalk.green('Smart cache cleared'));
      return prompt();
    }

    // ─── Web research agent ──────────────────────────────
    if (trimmed.startsWith('/search ')) {
      const q = trimmed.slice(8).trim();
      if (!q) { console.log(chalk.red('Usage: /search <your research question>')); return prompt(); }
      if (!process.env.TAVILY_API_KEY) {
        console.log(chalk.red('  TAVILY_API_KEY not set. Add it to .env to use web search.')); return prompt();
      }
      const sp = ora({ text: chalk.blue('Research agent running...'), spinner: 'dots' }).start();
      try {
        const result = await researchAgent(q);
        sp.succeed(chalk.green(`Research complete (${result.durationMs}ms)`));
        printSearchResult(result);
      } catch (err) {
        sp.fail(chalk.red('Research failed: ' + err.message));
      }
      return prompt();
    }

    // ─── History semantic search ─────────────────────────
    if (trimmed.startsWith('/history ')) {
      const q = trimmed.slice(9).trim();
      if (!isReady()) { console.log(chalk.yellow('  Vector store not available')); return prompt(); }
      const sp = ora('Searching history...').start();
      const { results } = await semanticSearch(COLLECTIONS.HISTORY, q, 5);
      sp.stop();
      if (!results.length) { console.log(chalk.gray('  No similar conversations found.')); }
      else {
        console.log(chalk.bold('\n🔍 Similar Past Conversations:'));
        results.forEach((r, i) => {
          const w  = r.metadata?.winner;
          const wc = w === 'Claude' ? 'cyan' : w === 'ChatGPT' ? 'green' : 'yellow';
          console.log(
            chalk.gray(`  ${i + 1}. [${(r.score * 100).toFixed(0)}%]`) + ' ' +
            chalk[wc](`[${w || '?'}]`) + ' ' +
            chalk.white(r.metadata?.prompt?.slice(0, 70))
          );
        });
        console.log('');
      }
      return prompt();
    }

    // ─── Self-improving eval ─────────────────────────────
    if (trimmed === '/eval') {
      const sp = ora({ text: chalk.yellow('Running self-improvement analysis...'), spinner: 'star' }).start();
      try {
        const report = await analyzeAndImprove('claude');
        sp.succeed(chalk.green('Analysis complete!'));
        printEvalReport(report);
      } catch (err) {
        sp.fail(chalk.red('Eval failed: ' + err.message));
      }
      return prompt();
    }

    // ─── Automatic prompt testing ────────────────────────
    if (trimmed === '/test') {
      console.log(chalk.yellow('\n  Running automatic prompt test suite...\n'));
      const testConfig = {
        name: 'Default Prompt Comparison',
        model: 'claude',
        variants: [
          {
            name: 'Direct',
            template: '{{INPUT}}',
          },
          {
            name: 'Chain-of-Thought',
            template: 'Think step by step, then answer:\n\n{{INPUT}}',
          },
          {
            name: 'Expert-Framed',
            template: 'As a world-class expert, provide a thorough answer:\n\n{{INPUT}}',
          },
        ],
        testCases: [
          { input: 'What is the difference between machine learning and deep learning?' },
          { input: 'Explain recursion in simple terms with an example.' },
          { input: 'What are the pros and cons of microservices architecture?' },
        ],
      };
      const sp = ora({ text: 'Testing prompt variants...', spinner: 'dots' }).start();
      try {
        const report = await runPromptTest(testConfig);
        sp.succeed(chalk.green('Prompt test complete!'));
        console.log('\n' + chalk.bold('📊 Prompt Test Results (ranked):'));
        report.results.forEach((r, i) => {
          const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : '🥉';
          console.log(`  ${medal} ${chalk.bold(r.variant.padEnd(20))} Score: ${chalk.yellow(r.avgScore.toFixed(2))} (${r.grade})`);
        });
        console.log(chalk.green(`\n  Winner: "${report.winner}"\n`));
      } catch (err) {
        sp.fail(chalk.red('Test failed: ' + err.message));
      }
      return prompt();
    }

    // ─── Dataset generation ──────────────────────────────
    if (trimmed.startsWith('/dataset')) {
      const topic = trimmed.slice(8).trim();
      if (!topic) {
        // Generate from history
        const history = loadHistory(10);
        if (history.length < 3) {
          console.log(chalk.yellow('  Need at least 3 comparisons. Try: /dataset <topic>'));
          return prompt();
        }
        const sp = ora('Generating dataset from history...').start();
        try {
          const dataset = await generateDataset(history, 'history_dataset');
          sp.succeed(chalk.green('Dataset generated!'));
          printDatasetReport(dataset);
        } catch (err) {
          sp.fail(chalk.red('Failed: ' + err.message));
        }
      } else {
        const sp = ora({ text: `Generating benchmark dataset for: "${topic}"...`, spinner: 'dots' }).start();
        try {
          const dataset = await generateBenchmark(topic, 15);
          sp.succeed(chalk.green(`Dataset generated: ${dataset.count} items`));
          printDatasetReport(dataset);
        } catch (err) {
          sp.fail(chalk.red('Failed: ' + err.message));
        }
      }
      return prompt();
    }

    // ─── List stored datasets ────────────────────────────
    if (trimmed === '/datasets') {
      const datasets = listDatasets();
      if (!datasets.length) { console.log(chalk.gray('  No datasets yet. Run /dataset <topic>')); }
      else {
        console.log(chalk.bold('\n🗂 Stored Datasets:'));
        datasets.forEach(d =>
          console.log(`  • ${chalk.cyan(d.name)} — ${chalk.yellow(d.count)} items — ${new Date(d.timestamp).toLocaleDateString()}`)
        );
        console.log('');
      }
      return prompt();
    }

    // ─── Main comparison flow ────────────────────────────
    let skipScoring  = false;
    let bypassCache  = false;
    let userPrompt   = trimmed;

    if (trimmed.startsWith('/quick ')) {
      skipScoring = true;
      userPrompt  = trimmed.slice(7).trim();
      if (!userPrompt) { console.log(chalk.red('Usage: /quick <question>')); return prompt(); }
    }

    if (trimmed.startsWith('/nocache ')) {
      bypassCache = true;
      userPrompt  = trimmed.slice(9).trim();
      if (!userPrompt) { console.log(chalk.red('Usage: /nocache <question>')); return prompt(); }
    }

    // Progress spinner management
    let sp = ora({ text: chalk.blue('Step 0/4 · Checking smart cache...'), spinner: 'dots2', color: 'blue' }).start();

    const steps = {
      cache_check: () => { /* spinner already running */ },
      rag:     () => { sp.succeed(chalk.blue('Cache miss — running full pipeline')); sp = ora({ text: chalk.cyan('Step 1/4 · RAG augmentation...'), spinner: 'dots2', color: 'cyan' }).start(); },
      llm:     () => { sp.succeed(chalk.green('Context ready!')); sp = ora({ text: chalk.magenta('Step 2/4 · Claude + GPT running in parallel...'), spinner: 'dots', color: 'magenta' }).start(); },
      scoring: () => { sp.succeed(chalk.green('Both AIs responded!')); sp = ora({ text: chalk.yellow('Step 3/4 · Scoring responses...'), spinner: 'star', color: 'yellow' }).start(); },
      saving:  () => { sp.succeed(chalk.green('Scoring complete!')); sp = ora({ text: chalk.gray('Step 4/4 · Caching + saving...'), spinner: 'line' }).start(); },
      done:    (data) => {
        if (data.fromCache) {
          sp.succeed(chalk.blue(`⚡ Cache HIT — answered instantly (score: ${data?.cacheScore?.toFixed(2) || '?'})`));
        } else {
          sp.succeed(chalk.green(`Done in ${data.durationMs}ms — answer cached for next time`));
        }
      },
    };

    try {
      const result = await runComparison(userPrompt, {
        useWebSearch,
        skipScoring,
        bypassCache,
        onProgress: (step, data) => steps[step]?.(data),
      });

      // ── Cache hit: show single cached answer ────────────
      if (result.fromCache) {
        console.log('\n' + chalk.bold.blue('⚡ INSTANT CACHE HIT'));
        console.log(chalk.gray(`   Similarity: ${(result.cacheScore * 100).toFixed(1)}%  |  Source: ${result.cacheSource}  |  Hit #${result.cacheHitCount}  |  Cached: ${result.cachedAt ? new Date(result.cachedAt).toLocaleDateString() : 'unknown'}`));
        console.log(chalk.blue('─'.repeat(70)));
        result.claude.text.split('\n').forEach(line =>
          console.log(chalk.white('  ' + line))
        );
        console.log(chalk.blue('─'.repeat(70)));
        console.log(chalk.gray('  Tip: use /nocache <question> to force fresh AI response\n'));
        return prompt();
      }

      if (skipScoring) { sp.succeed(chalk.green('Both AIs responded!')); }

      // Print responses
      printResponse('CLAUDE',  'cyan',  result.claude);
      printResponse('CHATGPT', 'green', result.openai);

      // Print scores
      if (result.comparison) {
        printScores('Claude',  result.comparison.Claude);
        printScores('ChatGPT', result.comparison.ChatGPT);
        printComparison(result.comparison);
      }

      // Token usage + cache footer
      const cu = result.claude.usage || {};
      const ou = result.openai.usage || {};
      console.log(chalk.gray(
        `\n  Tokens — Claude: ${cu.input || 0}↑ ${cu.output || 0}↓` +
        `  |  GPT: ${ou.input || 0}↑ ${ou.output || 0}↓` +
        `  |  RAG: ${result.ragResult?.hasContext ? chalk.blue('✔ augmented') : chalk.gray('no context')}` +
        `  |  ${chalk.blue('💾 cached')}` +
        `  |  ID: ${result.id?.slice(0, 8)}\n`
      ));

    } catch (err) {
      sp.fail(chalk.red('Error: ' + err.message));
      log.error('Comparison failed', err);
    }

    prompt();
  });

  prompt();
}

main().catch(err => {
  console.error(chalk.red('\nFatal error:'), err);
  process.exit(1);
});
