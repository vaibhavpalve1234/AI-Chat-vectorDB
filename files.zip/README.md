# utracodes-pro 🤖⚡

> **Autonomous Multi-Agent AI Evaluation System**  
> Claude vs GPT · RAG Memory · Web Search · Self-Improving Evals · Dataset Generation

---

## Architecture

```
                        You (CLI)
                            │
                ┌───────────▼────────────┐
                │   Orchestrator Agent   │  Master coordinator
                └──┬──────────┬──────────┘
                   │          │
          ┌────────▼──┐  ┌───▼────────┐
          │ RAG Engine │  │Tool Registry│
          │  ChromaDB  │  │ Web Search  │
          │  Retriever │  │ Code Exec   │
          └────────┬───┘  └────────────┘
                   │ augmented prompt
         ┌─────────┴──────────┐
         ▼                    ▼
   Claude Agent          OpenAI Agent
   (Anthropic SDK)       (GPT-4o SDK)
         │                    │
         └─────────┬──────────┘
                   ▼
            Scorer Agent
         (Multi-criteria LLM judge)
                   │
         ┌─────────┴──────────┐
         ▼                    ▼
   History Store        Vector Store
   (JSON + Evals)       (ChromaDB)
         │
         ▼
  Self-Improver Agent
  (Meta-learning from evals)
         │
         ▼
  Dataset Generator
  (Auto-creates benchmarks)
```

---

## Features

| Feature | Description |
|---|---|
| 🔎 **Web Search Agent** | Multi-step autonomous research with Tavily |
| 🤖 **Multi-Agent Reasoning** | Claude + GPT run in parallel, analyzed by a third agent |
| 🧠 **RAG Memory** | ChromaDB vector search augments every query with past context |
| 📊 **Response Scoring** | 6-dimension rubric: accuracy, completeness, helpfulness, reasoning, conciseness, groundedness |
| 🧪 **Prompt Testing** | A/B tests prompt variants on test suites, ranks by score |
| 🗂 **Dataset Generation** | Auto-generates Q&A benchmarks from conversations |
| ⚡ **Parallel Execution** | All LLM + tool calls run concurrently with retry/timeout |
| 🧬 **Self-Improving Evals** | Analyzes weak spots, generates improved system prompts |

---

## Quick Start

```bash
# 1. Install
cd utracodes-pro
npm install

# 2. Configure
cp .env.example .env
# → Add: ANTHROPIC_API_KEY, OPENAI_API_KEY, (optional) TAVILY_API_KEY

# 3. (Optional) Start ChromaDB for RAG memory
pip install chromadb
chroma run --path ./data/chromadb

# 4. Run
npm start
```

---

## Commands

| Command | Description |
|---|---|
| `<question>` | Compare Claude vs ChatGPT with full scoring |
| `/quick <q>` | Fast comparison, skip scoring |
| `/search <q>` | Autonomous web research (needs TAVILY_API_KEY) |
| `/eval` | Run self-improvement analysis on past responses |
| `/test` | Run automatic A/B prompt testing suite |
| `/dataset <topic>` | Generate benchmark dataset on a topic |
| `/datasets` | List all saved datasets |
| `/history <q>` | Semantic search past conversations |
| `/stats` | Leaderboard: Claude vs ChatGPT win rates |
| `/recent` | Show last 5 comparisons |
| `/web on\|off` | Toggle live web search in RAG pipeline |
| `/help` | Show all commands |
| `/exit` | Quit |

---

## File Structure

```
utracodes-pro/
├── src/
│   ├── index.js                 ← CLI entry point
│   ├── core/
│   │   ├── agentRunner.js       ← Parallel execution engine
│   │   ├── toolRegistry.js      ← Tool registration & dispatch
│   │   ├── display.js           ← Terminal UI renderer
│   │   └── logger.js            ← Structured logger
│   ├── agents/
│   │   ├── orchestrator.js      ← Master pipeline coordinator
│   │   ├── claudeAgent.js       ← Anthropic SDK wrapper
│   │   ├── openaiAgent.js       ← OpenAI SDK wrapper
│   │   ├── searchAgent.js       ← Autonomous web research
│   │   └── datasetAgent.js      ← Dataset generation
│   ├── rag/
│   │   ├── vectorStore.js       ← ChromaDB integration
│   │   └── retriever.js         ← RAG augmentation pipeline
│   ├── evals/
│   │   ├── scorer.js            ← Multi-criteria response scorer
│   │   ├── promptTester.js      ← Automatic prompt A/B testing
│   │   └── selfImprover.js      ← Meta-learning improvement engine
│   ├── tools/
│   │   ├── webSearch.js         ← Tavily search + extract
│   │   └── codeExecutor.js      ← Safe JS sandbox
│   └── storage/
│       ├── historyStore.js      ← Conversation persistence
│       ├── evalStore.js         ← Eval results storage
│       └── datasetStore.js      ← Dataset persistence
└── data/
    ├── history.json             ← All comparisons
    ├── evals/                   ← Eval results by category
    └── datasets/                ← Generated datasets
```

---

## API Keys

| Key | Required | Where to get |
|---|---|---|
| `ANTHROPIC_API_KEY` | ✅ Yes | [console.anthropic.com](https://console.anthropic.com) |
| `OPENAI_API_KEY` | ✅ Yes | [platform.openai.com](https://platform.openai.com/api-keys) |
| `TAVILY_API_KEY` | Optional | [tavily.com](https://tavily.com) — free tier available |

---

## Requirements

- Node.js 18+
- Python 3.8+ (optional, for ChromaDB)
