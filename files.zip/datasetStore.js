// ============================================================
//  src/storage/datasetStore.js
// ============================================================
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dir    = path.dirname(fileURLToPath(import.meta.url));
const DATASETS = path.resolve(__dir, '../../data/datasets');

function ensureDir() {
  if (!fs.existsSync(DATASETS)) fs.mkdirSync(DATASETS, { recursive: true });
}

export function saveDataset(dataset) {
  ensureDir();
  const file = path.join(DATASETS, `${dataset.name || dataset.id}.json`);
  fs.writeFileSync(file, JSON.stringify(dataset, null, 2), 'utf-8');
  return file;
}

export function loadDataset(name) {
  const file = path.join(DATASETS, `${name}.json`);
  if (!fs.existsSync(file)) return null;
  try { return JSON.parse(fs.readFileSync(file, 'utf-8')); } catch { return null; }
}

export function loadDatasets(limit = 10) {
  ensureDir();
  const files = fs.readdirSync(DATASETS).filter(f => f.endsWith('.json')).slice(0, limit);
  return files.map(f => {
    try { return JSON.parse(fs.readFileSync(path.join(DATASETS, f), 'utf-8')); } catch { return null; }
  }).filter(Boolean);
}

export function listDatasets() {
  ensureDir();
  return fs.readdirSync(DATASETS)
    .filter(f => f.endsWith('.json'))
    .map(f => {
      try {
        const d = JSON.parse(fs.readFileSync(path.join(DATASETS, f), 'utf-8'));
        return { name: d.name, count: d.count, timestamp: d.timestamp };
      } catch { return null; }
    }).filter(Boolean);
}
