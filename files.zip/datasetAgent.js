// ============================================================
//  src/agents/datasetAgent.js — Dataset Generation Agent
//  Auto-generates Q&A datasets from conversations for
//  fine-tuning, benchmarking, and future eval runs
// ============================================================
import { askClaude } from './claudeAgent.js';
import { saveDataset, loadDatasets } from '../storage/datasetStore.js';
import { log } from '../core/logger.js';
import { v4 as uuid } from 'uuid';

const GEN_SYSTEM = `You are a dataset generation expert. Create high-quality training examples 
for AI evaluation. Return ONLY valid JSON arrays, no explanations.`;

/**
 * Generate a Q&A dataset from a conversation entry.
 * @param {object} entry - From history store
 * @returns {Promise<DatasetItems[]>}
 */
export async function generateFromEntry(entry) {
  const { prompt, claude, openai } = entry;
  if (!prompt) return [];

  // Pick the better response as ground truth
  const claudeScore = claude?.score?.weightedScore || 0;
  const openaiScore = openai?.score?.weightedScore || 0;
  const bestResponse = claudeScore >= openaiScore ? claude?.text : openai?.text;
  const bestModel    = claudeScore >= openaiScore ? 'claude' : 'gpt';

  if (!bestResponse) return [];

  const genPrompt = `
Based on this Q&A pair, generate 3-5 related training examples.
Each example should test a DIFFERENT ASPECT of the same topic.

Original Question: "${prompt}"
Best Answer (${bestModel}): "${bestResponse.slice(0, 500)}"

Return JSON array:
[
  {
    "question": "...",
    "ideal_answer": "...",
    "category": "factual|reasoning|creative|technical|analysis",
    "difficulty": "easy|medium|hard",
    "tags": ["tag1", "tag2"]
  }
]`;

  try {
    const result  = await askClaude(genPrompt, { system: GEN_SYSTEM, temperature: 0.7 });
    const cleaned = result.text.replace(/```json\s*/gi, '').replace(/```/g, '').trim();
    const items   = JSON.parse(cleaned);
    return items.map(item => ({
      id:         uuid(),
      ...item,
      source:     'auto_generated',
      sourceEntry: entry.id,
      timestamp:  new Date().toISOString(),
    }));
  } catch (err) {
    log.warn('Dataset generation failed for entry', err.message);
    return [];
  }
}

/**
 * Generate a full dataset from recent history.
 * @param {object[]} history - Array of conversation entries
 * @param {string} datasetName
 */
export async function generateDataset(history, datasetName = 'auto_dataset') {
  log.agent('DatasetAgent', `Generating dataset from ${history.length} conversations`);

  const allItems = [];

  for (const entry of history.slice(0, 10)) { // cap at 10 to avoid huge API costs
    const items = await generateFromEntry(entry);
    allItems.push(...items);
  }

  // Deduplicate by question similarity (simple)
  const seen = new Set();
  const unique = allItems.filter(item => {
    const key = item.question?.slice(0, 50).toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const dataset = {
    id:        uuid(),
    name:      datasetName,
    timestamp: new Date().toISOString(),
    count:     unique.length,
    items:     unique,
    stats: {
      byCategory:  groupBy(unique, 'category'),
      byDifficulty: groupBy(unique, 'difficulty'),
    },
  };

  await saveDataset(dataset);
  log.success(`Dataset generated: ${unique.length} items saved as "${datasetName}"`);
  return dataset;
}

/**
 * Generate a specialized benchmark dataset on a topic.
 */
export async function generateBenchmark(topic, count = 20) {
  log.agent('DatasetAgent', `Generating ${count}-item benchmark for: "${topic}"`);

  const genPrompt = `Generate ${count} diverse benchmark questions about: "${topic}"

Include a mix of:
- Easy factual questions (30%)
- Medium reasoning questions (40%)  
- Hard analysis/synthesis questions (30%)

Return JSON array:
[
  {
    "question": "...",
    "ideal_answer": "...",
    "category": "factual|reasoning|analysis",
    "difficulty": "easy|medium|hard",
    "evaluation_criteria": "What makes a good answer to this question"
  }
]`;

  try {
    const result  = await askClaude(genPrompt, { system: GEN_SYSTEM, temperature: 0.8 });
    const cleaned = result.text.replace(/```json\s*/gi, '').replace(/```/g, '').trim();
    const items   = JSON.parse(cleaned);
    const dataset = {
      id:        uuid(),
      name:      `benchmark_${topic.replace(/\s+/g, '_').slice(0, 30)}`,
      timestamp: new Date().toISOString(),
      topic,
      count:     items.length,
      items:     items.map(i => ({ id: uuid(), ...i, source: 'benchmark' })),
    };
    await saveDataset(dataset);
    return dataset;
  } catch (err) {
    log.error('Benchmark generation failed', err);
    return { error: err.message };
  }
}

function groupBy(arr, key) {
  return arr.reduce((acc, item) => {
    const val = item[key] || 'unknown';
    acc[val] = (acc[val] || 0) + 1;
    return acc;
  }, {});
}
