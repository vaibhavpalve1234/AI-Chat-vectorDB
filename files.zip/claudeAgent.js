// ============================================================
//  src/agents/claudeAgent.js — Anthropic Claude Agent
//  Supports: basic completion, tool use, streaming metadata
// ============================================================
import Anthropic from '@anthropic-ai/sdk';
import { log } from '../core/logger.js';

let _client = null;
function client() {
  if (!_client) _client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  return _client;
}

const MODEL      = () => process.env.CLAUDE_MODEL   || 'claude-sonnet-4-6';
const MAX_TOKENS = () => parseInt(process.env.MAX_TOKENS) || 2000;

/**
 * Ask Claude a question. Returns structured result.
 */
export async function askClaude(prompt, options = {}) {
  const { system = '', temperature = 0.7, tools: toolDefs = [] } = options;
  const start = Date.now();

  const params = {
    model: MODEL(),
    max_tokens: MAX_TOKENS(),
    temperature,
    messages: [{ role: 'user', content: prompt }],
  };
  if (system) params.system = system;
  if (toolDefs.length) {
    params.tools = toolDefs;
    params.tool_choice = { type: 'auto' };
  }

  const response = await client().messages.create(params);

  const textBlocks = response.content.filter(b => b.type === 'text').map(b => b.text);
  const toolCalls  = response.content.filter(b => b.type === 'tool_use');

  return {
    text: textBlocks.join(''),
    toolCalls,
    model: response.model,
    stopReason: response.stop_reason,
    usage: { input: response.usage.input_tokens, output: response.usage.output_tokens },
    durationMs: Date.now() - start,
  };
}

/**
 * Multi-turn conversation with Claude.
 */
export async function chatClaude(messages, options = {}) {
  const { system = '', temperature = 0.7 } = options;
  const start = Date.now();

  const response = await client().messages.create({
    model: MODEL(),
    max_tokens: MAX_TOKENS(),
    temperature,
    system: system || undefined,
    messages,
  });

  return {
    text: response.content.filter(b => b.type === 'text').map(b => b.text).join(''),
    model: response.model,
    usage: { input: response.usage.input_tokens, output: response.usage.output_tokens },
    durationMs: Date.now() - start,
  };
}
