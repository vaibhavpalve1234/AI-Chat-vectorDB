// ============================================================
//  src/core/agentRunner.js — Parallel Agent Execution Engine
//  Runs multiple agents concurrently with retries, timeouts, 
//  and structured result collection
// ============================================================
import pLimit from 'p-limit';
import pRetry from 'p-retry';
import { log } from './logger.js';

// Max concurrent agent calls
const DEFAULT_CONCURRENCY = 5;
const DEFAULT_TIMEOUT_MS  = 30_000;
const DEFAULT_RETRIES     = 2;

/**
 * Run multiple agent tasks in parallel with concurrency control.
 *
 * @param {Array<{name: string, fn: () => Promise<any>, timeout?: number, retries?: number}>} tasks
 * @param {object} options
 * @returns {Promise<Array<{name, status, result, error, durationMs}>>}
 */
export async function runParallel(tasks, options = {}) {
  const { concurrency = DEFAULT_CONCURRENCY } = options;
  const limit = pLimit(concurrency);

  const wrappedTasks = tasks.map(task => limit(async () => {
    const start = Date.now();
    const timeout = task.timeout || DEFAULT_TIMEOUT_MS;
    const retries = task.retries ?? DEFAULT_RETRIES;

    try {
      const result = await pRetry(
        () => withTimeout(task.fn(), timeout),
        {
          retries,
          onFailedAttempt: (err) => {
            log.warn(`[${task.name}] attempt ${err.attemptNumber} failed: ${err.message}`);
          },
        }
      );
      return { name: task.name, status: 'fulfilled', result, durationMs: Date.now() - start };
    } catch (err) {
      log.error(`[${task.name}] failed after ${retries} retries`, err);
      return { name: task.name, status: 'rejected', error: err.message, durationMs: Date.now() - start };
    }
  }));

  return Promise.all(wrappedTasks);
}

/**
 * Run tasks in a pipeline (sequential), passing each result to the next.
 * @param {Array<{name: string, fn: (ctx: any) => Promise<any>}>} steps
 * @param {any} initialContext
 * @returns {Promise<any>} final context
 */
export async function runPipeline(steps, initialContext = {}) {
  let ctx = initialContext;
  for (const step of steps) {
    const start = Date.now();
    try {
      log.agent(step.name, 'starting...');
      ctx = await step.fn(ctx);
      log.success(`${step.name} completed (${Date.now() - start}ms)`);
    } catch (err) {
      log.error(`Pipeline step ${step.name} failed`, err);
      ctx = { ...ctx, [`${step.name}_error`]: err.message };
    }
  }
  return ctx;
}

/**
 * Wrap a promise with a timeout.
 */
function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Timeout after ${ms}ms`)), ms);
    promise.then(resolve, reject).finally(() => clearTimeout(timer));
  });
}

/**
 * Extract fulfilled results from a parallel run.
 */
export function getFulfilled(results) {
  return results.filter(r => r.status === 'fulfilled').map(r => ({ name: r.name, result: r.result, durationMs: r.durationMs }));
}

/**
 * Extract failed results from a parallel run.
 */
export function getFailed(results) {
  return results.filter(r => r.status === 'rejected');
}
