// ============================================================
//  src/evals/selfImprover.js — Self-Improving Evaluation Engine
//  Analyzes past scores, identifies patterns, generates
//  improved prompts using LLM meta-learning
// ============================================================
import { askClaude } from '../agents/claudeAgent.js';
import { loadEvals } from '../storage/evalStore.js';
import { log } from '../core/logger.js';
import { v4 as uuid } from 'uuid';
import { saveEval } from '../storage/evalStore.js';

const META_SYSTEM = `You are an expert AI prompt engineer and evaluator. 
Your job is to analyze evaluation results and suggest improvements to prompts and reasoning strategies.
Be specific, actionable, and data-driven. Return valid JSON only.`;

/**
 * Analyze eval history and generate improvement suggestions.
 * @param {string} agentName - 'claude' or 'gpt'
 * @returns {Promise<ImprovementReport>}
 */
export async function analyzeAndImprove(agentName = 'claude') {
  log.eval(`Running self-improvement analysis for: ${agentName}`);

  // Load recent eval history
  const history = await loadEvals('comparisons', 20);
  if (!history.length) {
    return { message: 'Not enough eval data yet. Run more comparisons first.', suggestions: [] };
  }

  // Build analytics
  const analytics = computeAnalytics(history, agentName);
  log.eval(`Analyzing ${analytics.totalSamples} samples...`, analytics.avgScores);

  const analysisPrompt = `
You are analyzing evaluation results for the AI model "${agentName}".

## Performance Data
- Total Evaluations: ${analytics.totalSamples}
- Average Weighted Score: ${analytics.overallAvg.toFixed(2)}/10

## Score Breakdown (0-10 per dimension):
${Object.entries(analytics.avgScores).map(([k, v]) => `- ${k}: ${v.toFixed(2)}`).join('\n')}

## Weakest Dimensions:
${analytics.weakest.map(([k, v]) => `- ${k}: ${v.toFixed(2)}`).join('\n')}

## Sample Low-Scoring Responses:
${analytics.lowScoringSamples.map((s, i) => `
Example ${i+1}:
  Question: "${s.question?.slice(0, 100)}"
  Response: "${s.response?.slice(0, 200)}"
  Score: ${s.score}
`).join('\n')}

## Sample High-Scoring Responses:
${analytics.highScoringSamples.map((s, i) => `
Example ${i+1}:
  Question: "${s.question?.slice(0, 100)}"
  Response: "${s.response?.slice(0, 200)}"
  Score: ${s.score}
`).join('\n')}

Based on this analysis, return a JSON object with:
{
  "patterns": ["pattern 1", "pattern 2"],
  "weaknesses": ["specific weakness 1", "specific weakness 2"],
  "improvements": [
    { "area": "accuracy", "suggestion": "...", "examplePromptAddition": "..." },
    { "area": "completeness", "suggestion": "...", "examplePromptAddition": "..." }
  ],
  "improvedSystemPrompt": "<a complete improved system prompt for this agent>",
  "predictedScoreGain": "<estimated improvement, e.g. +0.8 points>",
  "confidence": "low|medium|high"
}`;

  try {
    const result = await askClaude(analysisPrompt, { system: META_SYSTEM, temperature: 0.4 });

    const cleaned = result.text.replace(/```json\s*/gi, '').replace(/```/g, '').trim();
    const analysis = JSON.parse(cleaned);

    const report = {
      id:         uuid(),
      timestamp:  new Date().toISOString(),
      agentName,
      analytics,
      analysis,
    };

    await saveEval('improvements', report);
    log.eval(`Self-improvement analysis complete. Predicted gain: ${analysis.predictedScoreGain}`);
    return report;
  } catch (err) {
    log.error('Self-improvement analysis failed', err);
    return { error: err.message, analytics };
  }
}

/**
 * Generate a synthetic test suite from past conversations.
 */
export async function generateTestSuite(count = 10) {
  const history = await loadEvals('comparisons', 50);
  if (history.length < 5) {
    return { message: 'Need at least 5 comparisons to generate test suite.', tests: [] };
  }

  const samples = history.slice(0, 20).map(h => ({
    question: h.prompt,
    claudeScore: h.claude?.score?.weightedScore,
    gptScore:    h.openai?.score?.weightedScore,
  }));

  const genPrompt = `
Based on these past AI evaluation samples, generate a diverse test suite of ${count} questions.
Include: factual questions, reasoning tasks, coding problems, creative tasks, analysis tasks.

Past questions for context:
${samples.map(s => `- "${s.question?.slice(0, 80)}"`).join('\n')}

Return ONLY a JSON array:
[
  { "input": "question here", "category": "factual|reasoning|coding|creative|analysis", "difficulty": "easy|medium|hard" },
  ...
]`;

  try {
    const result = await askClaude(genPrompt, { temperature: 0.8 });
    const cleaned = result.text.replace(/```json\s*/gi, '').replace(/```/g, '').trim();
    const tests = JSON.parse(cleaned);
    return { tests, count: tests.length };
  } catch {
    return { message: 'Failed to generate test suite', tests: [] };
  }
}

// ─── Analytics Helpers ────────────────────────────────────

function computeAnalytics(history, agentName) {
  const samples = [];

  for (const entry of history) {
    const agentData = entry[agentName] || entry.claude || entry.openai;
    if (!agentData?.score?.scores) continue;

    samples.push({
      question: entry.prompt,
      response: agentData.text,
      score:    agentData.score.weightedScore,
      scores:   agentData.score.scores,
    });
  }

  if (!samples.length) return { totalSamples: 0, avgScores: {}, overallAvg: 0, weakest: [], lowScoringSamples: [], highScoringSamples: [] };

  const dims = ['accuracy', 'completeness', 'helpfulness', 'reasoning', 'conciseness', 'groundedness'];
  const avgScores = {};
  for (const dim of dims) {
    const vals = samples.map(s => s.scores[dim]?.score).filter(v => typeof v === 'number');
    avgScores[dim] = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
  }

  const overallAvg = samples.reduce((a, b) => a + b.score, 0) / samples.length;
  const weakest    = Object.entries(avgScores).sort((a, b) => a[1] - b[1]).slice(0, 3);

  const sorted = [...samples].sort((a, b) => a.score - b.score);

  return {
    totalSamples: samples.length,
    avgScores,
    overallAvg,
    weakest,
    lowScoringSamples:  sorted.slice(0, 3),
    highScoringSamples: sorted.slice(-3).reverse(),
  };
}
