// ============================================================
//  src/rag/vectorStore.js — ChromaDB Vector Store for RAG
//  Stores: conversation history, web search results, documents
// ============================================================
import { ChromaClient } from 'chromadb';
import { generateEmbedding } from '../agents/openaiAgent.js';
import { log } from '../core/logger.js';

const CHROMA_URL = () => process.env.CHROMA_URL || 'http://localhost:8000';

const COLLECTIONS = {
  HISTORY:  'utracodes_history',
  DOCS:     'utracodes_docs',
  EVALS:    'utracodes_evals',
  DATASETS: 'utracodes_datasets',
};

let _client = null;
const _cols  = {};
let   _ready = false;

export async function initVectorStore() {
  try {
    _client = new ChromaClient({ path: CHROMA_URL() });
    await _client.heartbeat();

    // Initialize all collections
    for (const [key, name] of Object.entries(COLLECTIONS)) {
      _cols[key] = await _client.getOrCreateCollection({
        name,
        metadata: { description: `utracodes-pro: ${name}` },
      });
    }

    _ready = true;
    const counts = await Promise.all(Object.entries(_cols).map(async ([k, c]) => `${k}:${await c.count()}`));
    log.rag(`ChromaDB ready — ${counts.join(' | ')}`);
    return true;
  } catch (err) {
    _ready = false;
    log.warn('ChromaDB not available — RAG will use keyword fallback', err.message);
    return false;
  }
}

export function isReady() { return _ready; }

/**
 * Add a document to a collection.
 * @param {'HISTORY'|'DOCS'|'EVALS'|'DATASETS'} collection
 * @param {object} doc - { id, text, metadata }
 */
export async function addDocument(collection, doc) {
  if (!_ready) return;
  try {
    const embedding = await generateEmbedding(doc.text);
    await _cols[collection].add({
      ids:        [doc.id],
      embeddings: [embedding],
      documents:  [doc.text],
      metadatas:  [{ ...doc.metadata, timestamp: new Date().toISOString() }],
    });
  } catch (err) {
    log.warn(`addDocument failed for ${collection}`, err.message);
  }
}

/**
 * Add multiple documents in batch.
 */
export async function addDocuments(collection, docs) {
  if (!_ready || !docs.length) return;
  try {
    const embeddings = await generateEmbedding(docs.map(d => d.text));
    await _cols[collection].add({
      ids:        docs.map(d => d.id),
      embeddings,
      documents:  docs.map(d => d.text),
      metadatas:  docs.map(d => ({ ...d.metadata, timestamp: new Date().toISOString() })),
    });
  } catch (err) {
    log.warn(`addDocuments batch failed`, err.message);
  }
}

/**
 * Semantic search in a collection.
 * @returns {Promise<Array<{id, text, metadata, score}>>}
 */
export async function semanticSearch(collection, query, topK = 5, filter = null) {
  if (!_ready) return { available: false, results: [] };
  try {
    const embedding = await generateEmbedding(query);
    const params = {
      queryEmbeddings: [embedding],
      nResults: Math.min(topK, 10),
    };
    if (filter) params.where = filter;

    const res = await _cols[collection].query(params);
    const results = (res.ids[0] || []).map((id, i) => ({
      id,
      text:     res.documents[0][i],
      metadata: res.metadatas[0][i],
      score:    1 - (res.distances?.[0]?.[i] ?? 1), // cosine sim
    }));
    return { available: true, results };
  } catch (err) {
    log.warn('semanticSearch failed', err.message);
    return { available: false, results: [] };
  }
}

/**
 * Get count for a collection.
 */
export async function getCount(collection) {
  if (!_ready || !_cols[collection]) return 0;
  try { return await _cols[collection].count(); } catch { return 0; }
}

export { COLLECTIONS };
