// ============================================================
//  src/core/logger.js — Structured Logger
// ============================================================
import chalk from 'chalk';

const LEVELS = { debug: 0, info: 1, warn: 2, error: 3 };
const currentLevel = LEVELS[process.env.LOG_LEVEL || 'info'];

const icons = { debug: '◌', info: '●', warn: '▲', error: '✕', success: '✔', agent: '◈', tool: '⚙', eval: '◆', rag: '◎' };

function timestamp() {
  return chalk.gray(new Date().toISOString().slice(11, 23));
}

export const log = {
  debug: (msg, meta) => currentLevel <= 0 && console.log(`${timestamp()} ${chalk.gray(icons.debug)} ${chalk.gray(msg)}`, meta || ''),
  info:  (msg, meta) => currentLevel <= 1 && console.log(`${timestamp()} ${chalk.blue(icons.info)} ${chalk.white(msg)}`, meta ? chalk.gray(JSON.stringify(meta)) : ''),
  warn:  (msg, meta) => currentLevel <= 2 && console.log(`${timestamp()} ${chalk.yellow(icons.warn)} ${chalk.yellow(msg)}`, meta || ''),
  error: (msg, err)  => currentLevel <= 3 && console.log(`${timestamp()} ${chalk.red(icons.error)} ${chalk.red(msg)}`, err?.message || err || ''),
  success:(msg, meta) => console.log(`${timestamp()} ${chalk.green(icons.success)} ${chalk.green(msg)}`, meta ? chalk.gray(JSON.stringify(meta)) : ''),
  agent: (name, msg) => console.log(`${timestamp()} ${chalk.magenta(icons.agent)} ${chalk.magenta(`[${name}]`)} ${chalk.white(msg)}`),
  tool:  (name, msg) => console.log(`${timestamp()} ${chalk.cyan(icons.tool)} ${chalk.cyan(`[${name}]`)} ${chalk.gray(msg)}`),
  eval:  (msg, meta) => console.log(`${timestamp()} ${chalk.yellow(icons.eval)} ${chalk.yellow(msg)}`, meta ? chalk.gray(JSON.stringify(meta)) : ''),
  rag:   (msg, meta) => console.log(`${timestamp()} ${chalk.blue(icons.rag)} ${chalk.blue(msg)}`, meta ? chalk.gray(JSON.stringify(meta)) : ''),
};
