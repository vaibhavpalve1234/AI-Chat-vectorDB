// ============================================================
//  src/core/display.js — Terminal Display Renderer
// ============================================================
import chalk    from 'chalk';
import boxen    from 'boxen';
import Table    from 'cli-table3';
import { RUBRIC } from '../evals/scorer.js';

export function printBanner() {
  console.log(boxen(
    chalk.bold.cyan(' utracodes') + chalk.bold.white('-pro') + ' ' + chalk.gray('v2.0') + '\n' +
    chalk.white('Autonomous Multi-Agent AI Evaluation System') + '\n' +
    chalk.gray('Claude · GPT · RAG · Web Search · Self-Improving Evals'),
    { padding: 1, margin: 1, borderStyle: 'double', borderColor: 'cyan' }
  ));
}

export function printHelp() {
  console.log(boxen(
    chalk.bold('Commands\n\n') +
    chalk.cyan('  /search <q>    ') + chalk.white('Autonomous web research agent\n') +
    chalk.cyan('  /quick <q>     ') + chalk.white('Compare without scoring (fast)\n') +
    chalk.cyan('  /eval          ') + chalk.white('Run self-improvement analysis\n') +
    chalk.cyan('  /test          ') + chalk.white('Auto prompt testing suite\n') +
    chalk.cyan('  /dataset <topic>') + chalk.white(' Generate benchmark dataset\n') +
    chalk.cyan('  /stats         ') + chalk.white('Show leaderboard & stats\n') +
    chalk.cyan('  /recent        ') + chalk.white('Last 5 comparisons\n') +
    chalk.cyan('  /history <q>   ') + chalk.white('Semantic search past chats\n') +
    chalk.cyan('  /web on|off    ') + chalk.white('Toggle web search in RAG\n') +
    chalk.cyan('  /cache         ') + chalk.white('Show cache stats (entries, hit rate)\n') +
    chalk.cyan('  /cache clear   ') + chalk.white('Wipe all cached answers\n') +
    chalk.cyan('  /nocache <q>   ') + chalk.white('Bypass cache, force fresh AI response\n') +
    chalk.cyan('  /help          ') + chalk.white('Show this menu\n') +
    chalk.cyan('  /exit          ') + chalk.white('Quit'),
    { padding: 1, borderStyle: 'single', borderColor: 'cyan' }
  ));
}

export function printResponse(label, color, result) {
  const header = chalk[color].bold(`┌─ ${label} `) +
    chalk.gray(`(${result.model}) `) +
    chalk.gray(`${result.durationMs}ms`);
  const border = chalk[color]('─'.repeat(70));

  console.log('\n' + header);
  result.text.split('\n').forEach(line =>
    console.log(chalk[color]('│ ') + chalk.white(line))
  );
  console.log(border);
}

export function printScores(label, scoreObj) {
  if (!scoreObj?.scores) return;
  const table = new Table({
    head: [chalk.bold('Dimension'), chalk.bold('Score'), chalk.bold('Grade'), chalk.bold('Reason')],
    colWidths: [16, 8, 7, 48],
    style: { head: [], border: [] },
  });

  for (const [dim] of Object.entries(RUBRIC)) {
    const d = scoreObj.scores[dim];
    if (!d) continue;
    const score = d.score ?? 0;
    const color = score >= 8 ? 'green' : score >= 6 ? 'yellow' : 'red';
    table.push([
      chalk.white(dim),
      chalk[color].bold(`${score}/10`),
      chalk[color](scoreToGrade(score)),
      chalk.gray((d.reason || '').slice(0, 45)),
    ]);
  }

  const ws = scoreObj.weightedScore;
  const wc = ws >= 8 ? 'green' : ws >= 6 ? 'yellow' : 'red';
  console.log(`\n${chalk.bold(label)} — Weighted Score: ${chalk[wc].bold(`${ws}/10`)} (${scoreObj.grade})`);
  console.log(table.toString());
}

export function printComparison(comparison) {
  if (!comparison) return;
  const wc = comparison.winner === 'Claude' ? 'cyan' : comparison.winner === 'ChatGPT' ? 'green' : 'yellow';
  console.log('\n' + boxen(
    chalk.bold('🏆  Winner: ') + chalk[wc].bold(comparison.winner) + '\n' +
    chalk.gray(`Margin: ${comparison.margin} pts  |  Confidence: ${comparison.confidence}`),
    { padding: { left: 3, right: 3, top: 0, bottom: 0 }, borderColor: wc, borderStyle: 'round' }
  ));
}

export function printSearchResult(result) {
  console.log('\n' + chalk.bold.blue('🔎 Research Result'));
  console.log(chalk.gray('─'.repeat(70)));
  result.answer.split('\n').forEach(line => console.log(chalk.white(line)));

  if (result.sources?.length) {
    console.log('\n' + chalk.bold('Sources:'));
    result.sources.slice(0, 5).forEach(s =>
      console.log(chalk.cyan(`  • ${s.title?.slice(0, 60) || s.url}`))
    );
  }
  console.log(chalk.gray(`\n  Searched ${result.searchCount} queries in ${result.durationMs}ms`));
}

export function printStats(stats) {
  if (!stats) { console.log(chalk.gray('\n  No history yet.\n')); return; }
  const total  = stats.total || 0;
  const cpct   = total ? ((stats.claudeWins / total) * 100).toFixed(0) : 0;
  const opct   = total ? ((stats.openaiWins / total) * 100).toFixed(0) : 0;

  console.log(boxen(
    chalk.bold('📊 Leaderboard\n\n') +
    chalk.cyan(`  Claude:  ${'█'.repeat(Math.floor(cpct / 5))}${'░'.repeat(20 - Math.floor(cpct / 5))} ${cpct}% (${stats.claudeWins} wins)\n`) +
    chalk.green(`  ChatGPT: ${'█'.repeat(Math.floor(opct / 5))}${'░'.repeat(20 - Math.floor(opct / 5))} ${opct}% (${stats.openaiWins} wins)\n`) +
    chalk.yellow(`  Ties:    ${stats.ties}\n`) +
    chalk.gray(`  Total:   ${stats.total} comparisons`),
    { padding: 1, borderColor: 'yellow', borderStyle: 'round' }
  ));
}

export function printEvalReport(report) {
  if (!report || report.error) {
    console.log(chalk.red(`Eval failed: ${report?.error || 'unknown error'}`));
    return;
  }
  const { analytics, analysis } = report;
  console.log('\n' + chalk.bold.yellow('🧬 Self-Improvement Report'));
  console.log(chalk.gray('─'.repeat(70)));

  if (analytics?.avgScores) {
    console.log(chalk.bold('\nCurrent Performance:'));
    for (const [dim, score] of Object.entries(analytics.avgScores)) {
      const bar = '█'.repeat(Math.floor(score)) + '░'.repeat(10 - Math.floor(score));
      const color = score >= 7 ? 'green' : score >= 5 ? 'yellow' : 'red';
      console.log(`  ${chalk.white(dim.padEnd(14))} ${chalk[color](bar)} ${chalk[color](score.toFixed(1))}`);
    }
  }

  if (analysis?.improvements) {
    console.log(chalk.bold('\nSuggested Improvements:'));
    analysis.improvements.forEach((imp, i) =>
      console.log(`  ${chalk.yellow(`${i + 1}.`)} ${chalk.cyan(`[${imp.area}]`)} ${chalk.white(imp.suggestion)}`)
    );
  }

  if (analysis?.predictedScoreGain) {
    console.log(`\n  ${chalk.bold('Predicted Score Gain:')} ${chalk.green(analysis.predictedScoreGain)}`);
  }

  if (analysis?.improvedSystemPrompt) {
    console.log('\n' + chalk.bold('Improved System Prompt:'));
    console.log(boxen(chalk.gray(analysis.improvedSystemPrompt.slice(0, 400)), {
      padding: 1, borderColor: 'green', borderStyle: 'single'
    }));
  }
}

export function printDatasetReport(dataset) {
  if (!dataset || dataset.error) {
    console.log(chalk.red(`Dataset failed: ${dataset?.error || 'unknown'}`));
    return;
  }
  console.log('\n' + chalk.bold.magenta('🗂 Dataset Generated'));
  console.log(chalk.gray('─'.repeat(70)));
  console.log(`  ${chalk.bold('Name:')}  ${chalk.white(dataset.name)}`);
  console.log(`  ${chalk.bold('Items:')} ${chalk.yellow(dataset.count)}`);
  if (dataset.stats?.byCategory) {
    console.log(`  ${chalk.bold('Categories:')} ` +
      Object.entries(dataset.stats.byCategory).map(([k, v]) => `${k}:${v}`).join(', '));
  }
  if (dataset.stats?.byDifficulty) {
    console.log(`  ${chalk.bold('Difficulty:')} ` +
      Object.entries(dataset.stats.byDifficulty).map(([k, v]) => `${k}:${v}`).join(', '));
  }
}

export function printRecent(history) {
  if (!history?.length) { console.log(chalk.gray('\n  No history yet.\n')); return; }
  console.log('\n' + chalk.bold('📜 Recent Comparisons:'));
  history.forEach((e, i) => {
    const w  = e.comparison?.winner;
    const wc = w === 'Claude' ? 'cyan' : w === 'ChatGPT' ? 'green' : 'yellow';
    const ts = new Date(e.timestamp).toLocaleString();
    console.log(
      chalk.gray(`  ${i + 1}. [${ts}]`) + ' ' +
      chalk[wc](`[${w || '?'}]`) + ' ' +
      chalk.white(e.prompt?.slice(0, 60))
    );
  });
  console.log('');
}

function scoreToGrade(s) {
  if (s >= 9) return 'A+'; if (s >= 8) return 'A';
  if (s >= 7) return 'B';  if (s >= 6) return 'C';
  if (s >= 5) return 'D';  return 'F';
}
