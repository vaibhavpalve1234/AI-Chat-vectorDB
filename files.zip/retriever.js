// ============================================================
//  src/rag/retriever.js — RAG Retrieval Pipeline
//  Retrieves relevant context from vector store + web search
//  then augments the prompt before sending to LLMs
// ============================================================
import { semanticSearch, isReady, COLLECTIONS } from './vectorStore.js';
import { searchAndExtract } from '../tools/webSearch.js';
import { log } from '../core/logger.js';

const SIMILARITY_THRESHOLD = 0.3;
const MAX_HISTORY_CHUNKS   = 3;
const MAX_DOC_CHUNKS       = 3;

/**
 * Full RAG pipeline:
 * 1. Semantic search in history + docs
 * 2. Optional live web search
 * 3. Build augmented prompt
 *
 * @param {string} query
 * @param {object} options
 * @returns {Promise<{augmentedPrompt, context, sources}>}
 */
export async function ragAugment(query, options = {}) {
  const {
    useWebSearch     = false,
    includeHistory   = true,
    includeDocs      = true,
    topK             = 5,
    systemContext    = '',
  } = options;

  const sources  = [];
  const contexts = [];

  // ─── 1. History search ─────────────────────────────────
  if (includeHistory && isReady()) {
    const { results: histResults } = await semanticSearch(COLLECTIONS.HISTORY, query, MAX_HISTORY_CHUNKS);
    const relevant = histResults.filter(r => r.score >= SIMILARITY_THRESHOLD);
    if (relevant.length) {
      log.rag(`Found ${relevant.length} relevant history chunks (threshold ${SIMILARITY_THRESHOLD})`);
      contexts.push('=== RELEVANT PAST CONVERSATIONS ===');
      for (const r of relevant) {
        contexts.push(`[${new Date(r.metadata?.timestamp || '').toLocaleDateString()}] ${r.text}`);
        sources.push({ type: 'history', id: r.id, score: r.score });
      }
    }
  }

  // ─── 2. Document search ─────────────────────────────────
  if (includeDocs && isReady()) {
    const { results: docResults } = await semanticSearch(COLLECTIONS.DOCS, query, MAX_DOC_CHUNKS);
    const relevant = docResults.filter(r => r.score >= SIMILARITY_THRESHOLD);
    if (relevant.length) {
      log.rag(`Found ${relevant.length} relevant document chunks`);
      contexts.push('=== RELEVANT DOCUMENTS ===');
      for (const r of relevant) {
        const src = r.metadata?.source || 'unknown';
        contexts.push(`[${src}] ${r.text}`);
        sources.push({ type: 'document', source: src, score: r.score });
      }
    }
  }

  // ─── 3. Live web search ─────────────────────────────────
  let webContext = null;
  if (useWebSearch && process.env.TAVILY_API_KEY) {
    try {
      log.rag(`Running web search for: "${query.slice(0, 60)}"`);
      const webResult = await searchAndExtract(query, 3);
      if (webResult.combinedContext) {
        webContext = webResult;
        contexts.push('=== WEB SEARCH RESULTS ===');
        contexts.push(webResult.combinedContext);
        sources.push({ type: 'web', query, resultCount: webResult.results.length });
      }
    } catch (err) {
      log.warn('Web search failed during RAG', err.message);
    }
  }

  // ─── 4. Build augmented prompt ──────────────────────────
  const hasContext = contexts.length > 0;
  let augmentedPrompt = query;

  if (hasContext) {
    const contextBlock = contexts.join('\n\n');
    augmentedPrompt = `${systemContext ? systemContext + '\n\n' : ''}You have access to the following context to help answer the question. Use it when relevant.

${contextBlock}

---
QUESTION: ${query}

Answer thoroughly based on the context above AND your own knowledge.`;
  }

  return {
    augmentedPrompt,
    originalQuery: query,
    hasContext,
    contextLength: augmentedPrompt.length,
    sources,
    webContext,
  };
}

/**
 * Quick keyword-based fallback search (when ChromaDB is down).
 */
export function keywordSearch(query, documents) {
  const words = query.toLowerCase().split(/\s+/).filter(w => w.length > 3);
  return documents
    .map(doc => ({
      ...doc,
      score: words.filter(w => doc.text?.toLowerCase().includes(w)).length / words.length,
    }))
    .filter(doc => doc.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);
}
