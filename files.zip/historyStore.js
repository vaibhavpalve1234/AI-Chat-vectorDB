// ============================================================
//  src/storage/historyStore.js — Conversation History Storage
// ============================================================
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dir  = path.dirname(fileURLToPath(import.meta.url));
const DATA   = path.resolve(__dir, '../../data');
const FILE   = path.join(DATA, 'history.json');

function read() {
  if (!fs.existsSync(FILE)) return [];
  try { return JSON.parse(fs.readFileSync(FILE, 'utf-8')); } catch { return []; }
}

function write(data) {
  if (!fs.existsSync(DATA)) fs.mkdirSync(DATA, { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2), 'utf-8');
}

export function saveHistory(entry) {
  const history = read();
  history.unshift(entry);
  write(history.slice(0, 500)); // keep last 500
}

export function loadHistory(limit = 50) {
  return read().slice(0, limit);
}

export function getHistoryStats() {
  const history = read();
  if (!history.length) return null;
  let cw = 0, ow = 0, ties = 0;
  for (const e of history) {
    const w = e.comparison?.winner;
    if (w === 'Claude') cw++;
    else if (w === 'ChatGPT') ow++;
    else ties++;
  }
  return { total: history.length, claudeWins: cw, openaiWins: ow, ties };
}
