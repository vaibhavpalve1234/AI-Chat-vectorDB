// ============================================================
//  src/tools/webSearch.js — Tavily Web Search Tool
//  Provides: search, extract, and deep research
// ============================================================
import { tavily } from '@tavily/core';
import { log } from '../core/logger.js';
import { registerTool } from '../core/toolRegistry.js';

let _client = null;
function client() {
  if (!_client) _client = tavily({ apiKey: process.env.TAVILY_API_KEY });
  return _client;
}

/**
 * Search the web and return structured results.
 * @param {string} query
 * @param {object} options
 */
export async function webSearch(query, options = {}) {
  const {
    maxResults    = 5,
    searchDepth   = 'advanced',
    includeAnswer = true,
    topic         = 'general',
  } = options;

  const response = await client().search(query, {
    maxResults,
    searchDepth,
    includeAnswer,
    topic,
  });

  return {
    query,
    answer:  response.answer || null,
    results: (response.results || []).map(r => ({
      title:   r.title,
      url:     r.url,
      content: r.content,
      score:   r.score,
    })),
    responseTime: response.responseTime,
  };
}

/**
 * Extract clean content from specific URLs.
 * @param {string[]} urls
 */
export async function webExtract(urls) {
  const response = await client().extract(urls);
  return {
    results: (response.results || []).map(r => ({
      url:        r.url,
      rawContent: r.rawContent?.slice(0, 3000), // cap at 3k chars
    })),
    failed: response.failedResults || [],
  };
}

/**
 * Search + extract in one shot: search for query, then extract top result.
 */
export async function searchAndExtract(query, maxResults = 3) {
  const search = await webSearch(query, { maxResults, searchDepth: 'advanced' });
  const topUrls = search.results.slice(0, 2).map(r => r.url);

  let extracted = [];
  if (topUrls.length) {
    try {
      const ext = await webExtract(topUrls);
      extracted = ext.results;
    } catch {
      log.warn('webExtract failed, using search snippets only');
    }
  }

  return {
    query,
    answer:  search.answer,
    results: search.results,
    extracted,
    combinedContext: buildContext(search, extracted),
  };
}

function buildContext(search, extracted) {
  const parts = [];
  if (search.answer) parts.push(`Summary: ${search.answer}`);
  for (const r of search.results) {
    parts.push(`[${r.title}] ${r.content}`);
  }
  for (const e of extracted) {
    if (e.rawContent) parts.push(`Full content from ${e.url}:\n${e.rawContent}`);
  }
  return parts.join('\n\n').slice(0, 8000); // keep context manageable
}

// Register as a tool
registerTool({
  name: 'web_search',
  description: 'Search the web for current information, facts, news, or any topic',
  schema: {
    type: 'object',
    properties: {
      query:      { type: 'string', description: 'The search query' },
      maxResults: { type: 'number', description: 'Max results to return (default 5)' },
    },
    required: ['query'],
  },
  execute: ({ query, maxResults }) => webSearch(query, { maxResults }),
});

registerTool({
  name: 'web_extract',
  description: 'Extract full content from specific URLs',
  schema: {
    type: 'object',
    properties: {
      urls: { type: 'array', items: { type: 'string' }, description: 'List of URLs to extract' },
    },
    required: ['urls'],
  },
  execute: ({ urls }) => webExtract(urls),
});
