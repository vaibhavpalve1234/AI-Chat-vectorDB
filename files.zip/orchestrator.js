// ============================================================
//  src/agents/orchestrator.js — Master Multi-Agent Orchestrator
//
//  Full pipeline per query:
//  0. Smart Cache lookup  ← skip everything if answer cached
//  1. RAG augmentation    (memory + optional web)
//  2. Claude + GPT in parallel
//  3. Response scoring
//  4. Cache + persist result
// ============================================================
import { askClaude }         from './claudeAgent.js';
import { askOpenAI }         from './openaiAgent.js';
import { ragAugment }        from '../rag/retriever.js';
import { compareResponses }  from '../evals/scorer.js';
import { saveHistory }       from '../storage/historyStore.js';
import { saveEval }          from '../storage/evalStore.js';
import { addDocument, COLLECTIONS, isReady } from '../rag/vectorStore.js';
import { checkCache, saveToCache }           from '../rag/smartCache.js';
import { runParallel }       from '../core/agentRunner.js';
import { log }               from '../core/logger.js';
import { v4 as uuid }        from 'uuid';

/**
 * Full comparison pipeline with smart cache.
 *
 * @param {string} prompt
 * @param {object} options
 * @param {boolean} options.useWebSearch   - Enable web search in RAG
 * @param {boolean} options.skipScoring    - Skip LLM-based scoring
 * @param {boolean} options.bypassCache    - Force re-run even on cache hit
 * @param {string}  options.systemPrompt
 * @param {function} options.onProgress    - callback(step, data)
 * @returns {Promise<ComparisonResult>}
 */
export async function runComparison(prompt, options = {}) {
  const {
    useWebSearch  = false,
    skipScoring   = false,
    bypassCache   = false,
    systemPrompt  = '',
    onProgress    = () => {},
  } = options;

  const id    = uuid();
  const start = Date.now();

  // ─── Step 0: Smart Cache Lookup ───────────────────────
  onProgress('cache_check', { step: 0 });
  log.agent('Orchestrator', 'Step 0: Smart cache lookup');

  if (!bypassCache) {
    const cacheResult = await checkCache(prompt);

    // Strong hit → return immediately, zero AI cost
    if (cacheResult.hit) {
      const cached = buildCachedResponse(id, prompt, cacheResult.entry, cacheResult);
      onProgress('done', { step: 1, durationMs: Date.now() - start, fromCache: true });
      return cached;
    }

    // Soft hit → log it, will be used as context in RAG
    if (cacheResult.soft) {
      log.rag(`Soft cache hit (score ${cacheResult.score.toFixed(2)}) — running AI with hint`);
    }
  }

  // ─── Step 1: RAG Augmentation ─────────────────────────
  onProgress('rag', { step: 1 });
  log.agent('Orchestrator', 'Step 1: RAG augmentation');

  const ragResult = await ragAugment(prompt, { useWebSearch, includeHistory: true, includeDocs: true });
  if (ragResult.hasContext) {
    log.rag(`Augmented with ${ragResult.sources.length} sources (${ragResult.contextLength} chars)`);
  }

  // ─── Step 2: Parallel LLM Calls ───────────────────────
  onProgress('llm', { step: 2 });
  log.agent('Orchestrator', 'Step 2: Parallel LLM inference');

  const llmResults = await runParallel([
    { name: 'claude', fn: () => askClaude(ragResult.augmentedPrompt, { system: systemPrompt, temperature: 0.7 }) },
    { name: 'openai', fn: () => askOpenAI(ragResult.augmentedPrompt, { system: systemPrompt, temperature: 0.7 }) },
  ], { concurrency: 2 });

  const claudeRes  = llmResults.find(r => r.name === 'claude');
  const openaiRes  = llmResults.find(r => r.name === 'openai');

  const claudeData = claudeRes?.status === 'fulfilled'
    ? claudeRes.result
    : { text: `❌ Claude Error: ${claudeRes?.error}`, model: 'error', usage: {}, durationMs: 0 };

  const openaiData = openaiRes?.status === 'fulfilled'
    ? openaiRes.result
    : { text: `❌ GPT Error: ${openaiRes?.error}`, model: 'error', usage: {}, durationMs: 0 };

  // ─── Step 3: Scoring ──────────────────────────────────
  let comparison = null;
  if (!skipScoring && claudeData.model !== 'error' && openaiData.model !== 'error') {
    onProgress('scoring', { step: 3 });
    log.agent('Orchestrator', 'Step 3: Response scoring');
    try { comparison = await compareResponses(prompt, claudeData.text, openaiData.text); }
    catch (err) { log.warn('Scoring failed', err.message); }
  }

  // ─── Step 4: Persist + Cache ──────────────────────────
  onProgress('saving', { step: 4 });

  const entry = {
    id, timestamp: new Date().toISOString(), prompt,
    ragSources: ragResult.sources, fromCache: false,
    claude:  { text: claudeData.text, model: claudeData.model, usage: claudeData.usage, durationMs: claudeData.durationMs, score: comparison?.Claude },
    openai:  { text: openaiData.text, model: openaiData.model, usage: openaiData.usage, durationMs: openaiData.durationMs, score: comparison?.ChatGPT },
    comparison: comparison ? { winner: comparison.winner, margin: comparison.margin, confidence: comparison.confidence } : null,
    durationMs: Date.now() - start,
  };

  saveHistory(entry);
  saveEval('comparisons', entry);

  // Save winner answer to smart cache
  const winner      = comparison?.winner;
  const winnerText  = winner === 'Claude' ? claudeData.text : winner === 'ChatGPT' ? openaiData.text : claudeData.text;
  const winnerModel = winner === 'Claude' ? claudeData.model : winner === 'ChatGPT' ? openaiData.model : claudeData.model;

  saveToCache(prompt, {
    answer:        winnerText,
    source:        winner?.toLowerCase() || 'claude',
    model:         winnerModel,
    webSearchUsed: useWebSearch,
    qualityScore:  winner === 'Claude'  ? comparison?.Claude?.weightedScore
                 : winner === 'ChatGPT' ? comparison?.ChatGPT?.weightedScore : null,
  }).catch(err => log.warn('Cache save failed', err.message));

  // Index in history vector store
  if (isReady()) {
    const docText = `Q: ${prompt}\nClaude: ${claudeData.text.slice(0, 500)}\nGPT: ${openaiData.text.slice(0, 500)}`;
    addDocument(COLLECTIONS.HISTORY, {
      id, text: docText,
      metadata: { prompt: prompt.slice(0, 200), winner: comparison?.winner || 'unknown', score_claude: comparison?.Claude?.weightedScore || 0, score_gpt: comparison?.ChatGPT?.weightedScore || 0 },
    }).catch(() => {});
  }

  onProgress('done', { step: 5, durationMs: entry.durationMs, fromCache: false });

  return { id, prompt, claude: entry.claude, openai: entry.openai, comparison, ragResult, durationMs: entry.durationMs, fromCache: false };
}

// ─── Wrap a cache hit into the standard result shape ──────
function buildCachedResponse(id, prompt, entry, cacheResult) {
  const answer      = entry.answer || '';
  const fakeResponse = { text: answer, model: entry.model || 'cached', usage: { input: 0, output: 0 }, durationMs: 0 };
  return {
    id, prompt, fromCache: true,
    cacheScore:    cacheResult.score,
    cacheSource:   cacheResult.source,
    cachedAt:      entry.createdAt,
    cacheHitCount: (entry.hitCount || 0) + 1,
    claude: { ...fakeResponse, cachedFrom: entry.source },
    openai: { ...fakeResponse, cachedFrom: entry.source },
    comparison: null,
    ragResult:  { hasContext: false, sources: [] },
    durationMs: 0,
  };
}
