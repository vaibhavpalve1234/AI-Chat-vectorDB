// ============================================================
//  src/agents/openaiAgent.js — OpenAI GPT Agent
//  Supports: chat completions, embeddings, structured outputs
// ============================================================
import OpenAI from 'openai';

let _client = null;
function client() {
  if (!_client) _client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  return _client;
}

const MODEL      = () => process.env.OPENAI_MODEL || 'gpt-4o';
const MAX_TOKENS = () => parseInt(process.env.MAX_TOKENS) || 2000;

/**
 * Ask GPT a question. Returns structured result.
 */
export async function askOpenAI(prompt, options = {}) {
  const { system = '', temperature = 0.7, responseFormat = null } = options;
  const start = Date.now();

  const messages = [];
  if (system) messages.push({ role: 'system', content: system });
  messages.push({ role: 'user', content: prompt });

  const params = { model: MODEL(), max_tokens: MAX_TOKENS(), temperature, messages };
  if (responseFormat) params.response_format = responseFormat;

  const response = await client().chat.completions.create(params);
  const choice = response.choices[0];

  return {
    text: choice.message.content || '',
    model: response.model,
    stopReason: choice.finish_reason,
    usage: { input: response.usage.prompt_tokens, output: response.usage.completion_tokens },
    durationMs: Date.now() - start,
  };
}

/**
 * Ask GPT and get a JSON object back.
 */
export async function askOpenAIJson(prompt, options = {}) {
  const result = await askOpenAI(prompt, { ...options, responseFormat: { type: 'json_object' } });
  try {
    return { ...result, json: JSON.parse(result.text) };
  } catch {
    return { ...result, json: null, parseError: true };
  }
}

/**
 * Generate embeddings for a text string.
 * @param {string | string[]} input
 * @returns {Promise<number[] | number[][]>}
 */
export async function generateEmbedding(input) {
  const isArray = Array.isArray(input);
  const response = await client().embeddings.create({
    model: 'text-embedding-3-small',
    input: isArray ? input : [input],
  });
  const vecs = response.data.map(d => d.embedding);
  return isArray ? vecs : vecs[0];
}

/**
 * Multi-turn conversation with GPT.
 */
export async function chatOpenAI(messages, options = {}) {
  const { temperature = 0.7 } = options;
  const start = Date.now();
  const response = await client().chat.completions.create({
    model: MODEL(), max_tokens: MAX_TOKENS(), temperature, messages,
  });
  return {
    text: response.choices[0].message.content || '',
    model: response.model,
    usage: { input: response.usage.prompt_tokens, output: response.usage.completion_tokens },
    durationMs: Date.now() - start,
  };
}
