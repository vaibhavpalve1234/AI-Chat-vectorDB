// ============================================================
//  src/tools/codeExecutor.js — Safe Code Execution Tool
//  Uses Node.js child_process with strict timeout + memory cap
//  (isolated-vm has native build requirements, so we use
//   subprocess isolation which is safer for production)
// ============================================================
import { execFile } from 'child_process';
import { writeFileSync, unlinkSync, existsSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { randomUUID } from 'crypto';
import { log } from '../core/logger.js';
import { registerTool } from '../core/toolRegistry.js';

const TIMEOUT_MS   = 5_000;  // 5 second max
const MAX_OUTPUT   = 4_000;  // 4kb output cap

/**
 * Execute JavaScript code safely in a subprocess.
 * @param {string} code
 * @returns {Promise<{stdout, stderr, exitCode, error}>}
 */
export async function executeCode(code) {
  const id   = randomUUID().slice(0, 8);
  const file = join(tmpdir(), `utracodes_exec_${id}.mjs`);

  // Wrap code to capture console output
  const wrapped = `
// Safe execution wrapper
const _logs = [];
const _origLog = console.log;
const _origErr = console.error;
console.log = (...a) => _logs.push(['log', a.map(String).join(' ')]);
console.error = (...a) => _logs.push(['err', a.map(String).join(' ')]);

try {
  ${code}
} catch (e) {
  console.error('RuntimeError: ' + e.message);
}

for (const [t, m] of _logs) {
  if (t === 'log') process.stdout.write(m + '\\n');
  else process.stderr.write(m + '\\n');
}
`;

  writeFileSync(file, wrapped, 'utf-8');

  return new Promise((resolve) => {
    execFile(
      process.execPath,
      ['--no-warnings', '--experimental-vm-modules', file],
      {
        timeout: TIMEOUT_MS,
        maxBuffer: MAX_OUTPUT,
        env: {
          // Minimal env — no secrets, no API keys
          PATH: process.env.PATH,
          NODE_ENV: 'sandbox',
        },
      },
      (err, stdout, stderr) => {
        // Always clean up
        try { if (existsSync(file)) unlinkSync(file); } catch {}

        if (err?.killed) {
          resolve({ stdout: '', stderr: 'Execution timed out', exitCode: 124, timedOut: true });
        } else {
          resolve({
            stdout:   stdout.slice(0, MAX_OUTPUT),
            stderr:   stderr.slice(0, MAX_OUTPUT),
            exitCode: err?.code ?? 0,
            error:    err?.message?.includes('maxBuffer') ? 'Output too large' : null,
          });
        }
      }
    );
  });
}

// Register as tool
registerTool({
  name: 'execute_code',
  description: 'Execute JavaScript code and return the output. Good for calculations, data processing, algorithms.',
  schema: {
    type: 'object',
    properties: {
      code: { type: 'string', description: 'JavaScript code to execute' },
    },
    required: ['code'],
  },
  execute: ({ code }) => executeCode(code),
});
