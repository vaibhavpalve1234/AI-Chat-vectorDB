// ============================================================
//  src/core/toolRegistry.js — Central Tool Registry
//  All tools register here. Agents call tools by name.
// ============================================================
import { log } from './logger.js';

const tools = new Map();

/**
 * Register a tool.
 * @param {object} def
 * @param {string} def.name
 * @param {string} def.description
 * @param {object} def.schema - JSON schema of input params
 * @param {Function} def.execute - async (params) => result
 */
export function registerTool(def) {
  tools.set(def.name, def);
  log.debug(`Tool registered: ${def.name}`);
}

/**
 * Execute a tool by name.
 * @param {string} name
 * @param {object} params
 * @returns {Promise<any>}
 */
export async function executeTool(name, params = {}) {
  const tool = tools.get(name);
  if (!tool) throw new Error(`Tool not found: ${name}`);

  const start = Date.now();
  log.tool(name, `executing with params: ${JSON.stringify(params).slice(0, 100)}`);

  try {
    const result = await tool.execute(params);
    log.tool(name, `done in ${Date.now() - start}ms`);
    return result;
  } catch (err) {
    log.error(`Tool ${name} failed`, err);
    throw err;
  }
}

/**
 * Execute multiple tools in parallel.
 * @param {Array<{name: string, params: object}>} calls
 * @returns {Promise<Array<{name, result, error}>>}
 */
export async function executeToolsParallel(calls) {
  const results = await Promise.allSettled(
    calls.map(({ name, params }) =>
      executeTool(name, params).then(result => ({ name, result }))
    )
  );
  return results.map((r, i) => ({
    name: calls[i].name,
    result: r.status === 'fulfilled' ? r.value.result : null,
    error:  r.status === 'rejected'  ? r.reason.message : null,
  }));
}

/** Get all registered tool definitions (for LLM tool calling). */
export function getToolDefinitions() {
  return Array.from(tools.values()).map(({ name, description, schema }) => ({
    name, description, parameters: schema,
  }));
}

export function getTool(name) {
  return tools.get(name);
}

export function listTools() {
  return Array.from(tools.keys());
}
