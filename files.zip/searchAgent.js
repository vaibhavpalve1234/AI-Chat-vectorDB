// ============================================================
//  src/agents/searchAgent.js — Autonomous Web Research Agent
//  Plans searches, executes them, synthesizes into an answer
// ============================================================
import { askClaude } from './claudeAgent.js';
import { webSearch, searchAndExtract } from '../tools/webSearch.js';
import { log } from '../core/logger.js';
import { runParallel } from '../core/agentRunner.js';

const PLANNER_SYSTEM = `You are a research planning agent. Given a question, 
generate 2-4 targeted search queries to find the best answer.
Return ONLY a JSON array of query strings. No explanations.`;

const SYNTHESIZER_SYSTEM = `You are a research synthesis expert. 
Given multiple web search results, synthesize a comprehensive, accurate answer.
Always cite sources. Be factual and objective.`;

/**
 * Autonomous research agent:
 * 1. Plans optimal search queries
 * 2. Runs searches in parallel
 * 3. Synthesizes all results into one answer
 *
 * @param {string} question
 * @param {object} options
 * @returns {Promise<ResearchResult>}
 */
export async function researchAgent(question, options = {}) {
  const { maxQueries = 3, searchDepth = 'advanced' } = options;
  const start = Date.now();

  log.agent('SearchAgent', `Researching: "${question.slice(0, 70)}"`);

  // ─── Step 1: Plan queries ──────────────────────────────
  let queries = [question]; // fallback: use question directly
  try {
    const planResult = await askClaude(
      `Generate ${maxQueries} targeted search queries for: "${question}"\nReturn JSON array only.`,
      { system: PLANNER_SYSTEM, temperature: 0.3 }
    );
    const cleaned = planResult.text.replace(/```json\s*/gi, '').replace(/```/g, '').trim();
    const parsed  = JSON.parse(cleaned);
    if (Array.isArray(parsed) && parsed.length) {
      queries = parsed.slice(0, maxQueries);
      log.agent('SearchAgent', `Planned ${queries.length} queries`);
    }
  } catch {
    log.warn('Query planning failed, using original question');
  }

  // ─── Step 2: Run searches in parallel ─────────────────
  const searchTasks = queries.map((q, i) => ({
    name: `search_${i}`,
    fn:   () => searchAndExtract(q, 3),
  }));

  const searchResults = await runParallel(searchTasks, { concurrency: 3 });
  const successful    = searchResults.filter(r => r.status === 'fulfilled');

  if (!successful.length) {
    return { question, answer: 'Web search unavailable.', sources: [], durationMs: Date.now() - start };
  }

  // ─── Step 3: Build context from all results ────────────
  const allContext = [];
  const allSources = [];

  for (const r of successful) {
    const data = r.result;
    if (data.answer)          allContext.push(`Search summary: ${data.answer}`);
    if (data.combinedContext) allContext.push(data.combinedContext);
    allSources.push(...(data.results || []).map(res => ({ title: res.title, url: res.url })));
  }

  const contextText = allContext.join('\n\n---\n\n').slice(0, 10_000);

  // ─── Step 4: Synthesize final answer ──────────────────
  const synthesisPrompt = `
Research Question: "${question}"

Web Search Results:
${contextText}

Provide a comprehensive, well-sourced answer. Be specific and factual.`;

  const synthesis = await askClaude(synthesisPrompt, {
    system:      SYNTHESIZER_SYSTEM,
    temperature: 0.4,
  });

  return {
    question,
    answer:      synthesis.text,
    queries,
    sources:     deduplicateSources(allSources).slice(0, 8),
    searchCount: successful.length,
    durationMs:  Date.now() - start,
    model:       synthesis.model,
  };
}

/**
 * Quick single-query search (no planning step).
 */
export async function quickSearch(query) {
  const result = await searchAndExtract(query, 3);
  return {
    query,
    answer:  result.answer,
    results: result.results.slice(0, 3),
    context: result.combinedContext,
  };
}

function deduplicateSources(sources) {
  const seen = new Set();
  return sources.filter(s => {
    if (seen.has(s.url)) return false;
    seen.add(s.url);
    return true;
  });
}
