// ============================================================
//  src/evals/scorer.js — Multi-Criteria Response Scorer
//  Scores responses on: accuracy, completeness, helpfulness,
//  groundedness, conciseness, and reasoning quality
// ============================================================
import { askOpenAIJson } from '../agents/openaiAgent.js';
import { log } from '../core/logger.js';

// Scoring dimensions with weights
export const RUBRIC = {
  accuracy:      { weight: 0.25, desc: 'Factual correctness and absence of hallucinations' },
  completeness:  { weight: 0.20, desc: 'How fully the question is answered' },
  helpfulness:   { weight: 0.20, desc: 'Practical value and actionability' },
  reasoning:     { weight: 0.15, desc: 'Quality of logical reasoning and explanation' },
  conciseness:   { weight: 0.10, desc: 'Appropriate length, no filler' },
  groundedness:  { weight: 0.10, desc: 'Evidence-based, cites sources when available' },
};

const SCORING_SYSTEM = `You are an expert AI response evaluator. Score each response dimension from 0-10.
Return ONLY valid JSON. Be strict and objective — 10 means perfect, 5 means mediocre, 0 means terrible.`;

/**
 * Score a single response against a question.
 * @param {string} question
 * @param {string} response
 * @param {string} [reference] - Optional reference/ground truth
 * @returns {Promise<ScoredResult>}
 */
export async function scoreResponse(question, response, reference = '') {
  const prompt = `
Question: "${question}"
${reference ? `Reference Answer: "${reference}"` : ''}

Response to evaluate:
"${response.slice(0, 2000)}"

Score this response on each dimension (0-10). Return JSON with this EXACT structure:
{
  "accuracy":     { "score": <0-10>, "reason": "<one sentence>" },
  "completeness": { "score": <0-10>, "reason": "<one sentence>" },
  "helpfulness":  { "score": <0-10>, "reason": "<one sentence>" },
  "reasoning":    { "score": <0-10>, "reason": "<one sentence>" },
  "conciseness":  { "score": <0-10>, "reason": "<one sentence>" },
  "groundedness": { "score": <0-10>, "reason": "<one sentence>" },
  "strengths":    ["<strength 1>", "<strength 2>"],
  "weaknesses":   ["<weakness 1>"]
}`;

  try {
    const result = await askOpenAIJson(prompt, { system: SCORING_SYSTEM, temperature: 0.3 });
    if (!result.json) throw new Error('Failed to parse scoring JSON');

    const scores  = result.json;
    const weighted = computeWeightedScore(scores);

    return {
      scores,
      weightedScore: weighted,
      grade: scoreToGrade(weighted),
      usage: result.usage,
    };
  } catch (err) {
    log.warn('Scoring failed, using fallback', err.message);
    return fallbackScore(response);
  }
}

/**
 * Compare two responses and pick the winner.
 */
export async function compareResponses(question, responseA, responseB, labels = ['Claude', 'ChatGPT']) {
  const [scoreA, scoreB] = await Promise.all([
    scoreResponse(question, responseA),
    scoreResponse(question, responseB),
  ]);

  const winner = scoreA.weightedScore > scoreB.weightedScore
    ? labels[0]
    : scoreB.weightedScore > scoreA.weightedScore
    ? labels[1]
    : 'Tie';

  const margin = Math.abs(scoreA.weightedScore - scoreB.weightedScore);

  return {
    [labels[0]]: scoreA,
    [labels[1]]: scoreB,
    winner,
    margin: margin.toFixed(2),
    confidence: margin < 0.5 ? 'low' : margin < 1.5 ? 'medium' : 'high',
  };
}

/**
 * Batch score multiple responses.
 */
export async function batchScore(items) {
  const results = await Promise.allSettled(
    items.map(({ question, response, reference }) =>
      scoreResponse(question, response, reference)
    )
  );
  return results.map((r, i) => ({
    ...items[i],
    score: r.status === 'fulfilled' ? r.value : null,
    error: r.status === 'rejected' ? r.reason.message : null,
  }));
}

// ─── Helpers ──────────────────────────────────────────────

function computeWeightedScore(scores) {
  let total = 0, weightSum = 0;
  for (const [dim, rubric] of Object.entries(RUBRIC)) {
    const s = scores[dim]?.score;
    if (typeof s === 'number') {
      total     += s * rubric.weight;
      weightSum += rubric.weight;
    }
  }
  return weightSum > 0 ? parseFloat((total / weightSum).toFixed(2)) : 0;
}

function scoreToGrade(score) {
  if (score >= 9) return 'A+';
  if (score >= 8) return 'A';
  if (score >= 7) return 'B';
  if (score >= 6) return 'C';
  if (score >= 5) return 'D';
  return 'F';
}

function fallbackScore(response) {
  const len = response.length;
  const base = Math.min(10, Math.max(3, len / 200));
  return {
    scores: Object.fromEntries(
      Object.keys(RUBRIC).map(k => [k, { score: base, reason: 'Fallback estimate' }])
    ),
    weightedScore: parseFloat(base.toFixed(2)),
    grade: scoreToGrade(base),
    fallback: true,
  };
}
